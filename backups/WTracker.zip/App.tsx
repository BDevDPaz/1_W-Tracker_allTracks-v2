// ============================================================
// APP ENTRY POINT: W Tracker V2.0.0 — Workday Tracking (CONSOLIDADO)
// Versión: 2.0.0 (Workday Tracking Design System)
// Fuente: Fase 1 (Infraestructura) | Matriz de Resiliencia V2.1
// Responsabilidad: Orquestación de secuencia de arranque, rehidratación forense y contexto global.
// ============================================================

import { NavigationContainer, Theme } from '@react-navigation/native';
import * as SplashScreen from 'expo-splash-screen';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, LogBox, StatusBar, StyleSheet, Text, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// ── INFRAESTRUCTURA Y NAVEGACIÓN ─────────────────────────────
import { AppNavigator } from './src/navigation/AppNavigator';
import { PALETTE, TEXT } from './src/theme';

// ── SERVICIOS Y ESTADO GLOBAL (SINGLETONS) ───────────────────
import { DatabaseService } from './src/services/database/DatabaseService';
import { geofenceService } from './src/services/geofence/GeofenceService';
import { sessionEngine } from './src/services/sessionEngine/SessionEngineService';
import { settingsService } from './src/services/settings/SettingsService';
import { ToastProvider, ToastService } from './src/services/toast/ToastService';
import { useSessionStore } from './src/stores/sessionStore';

// Ignorar advertencias de navegación no serializable (necesario para funciones en params)
LogBox.ignoreLogs(['Non-serializable values were found in the navigation state']);

// Prevenir que el Splash nativo se oculte prematuramente para evitar parpadeos
SplashScreen.preventAutoHideAsync().catch(() => {});

type AppBootState = 'BOOTING' | 'READY' | 'ERROR';

// ── PANTALLA DE CARGA (BOOT SCREEN) ──────────────────────────

const BootScreen: React.FC<{ error?: string }> = ({ error }) => (
  <View style={bootStyles.container}>
    <Text style={bootStyles.brand}>W</Text>
    <Text style={bootStyles.brandSub}>TRACKER</Text>
    
    {error ? (
      <View style={bootStyles.errorBox}>
        <Text style={bootStyles.errorTitle}>Fallo de Infraestructura</Text>
        <Text style={bootStyles.errorText}>{error}</Text>
      </View>
    ) : (
      <View style={bootStyles.loadingBox}>
        <Text style={bootStyles.loadingText}>INICIALIZANDO MOTOR OPERATIVO</Text>
        <ActivityIndicator size="small" color={PALETTE.mutedGold} style={bootStyles.spinner} />
      </View>
    )}
  </View>
);

// ── COMPONENTE RAÍZ ──────────────────────────────────────────

export default function App() {
  const [bootState, setBootState] = useState<AppBootState>('BOOTING');
  const [bootError, setBootError] = useState<string | undefined>();

  /**
   * Pipeline Crítico de Arranque y Rehidratación
   */
  const bootstrap = useCallback(async () => {
    try {
      // 1. Inicializar SQLite y el Esquema Relacional
      await DatabaseService.initialize();

      // 2. Cargar Parámetros de Gobierno (Nómina, Radios, Multiplicadores)
      await settingsService.load();

      // 3. Rehidratación Forense WAL (Resiliencia ante cierres del OS)
      const recoveryResult = await sessionEngine.rehydrateFromWAL();

      if (recoveryResult === 'RECOVERED') {
        ToastService.push({
          type: 'info',
          text: 'Sesión operativa recuperada automáticamente',
        });
      } else if (recoveryResult === 'CONFLICT') {
        ToastService.push({
          type: 'warning',
          text: 'Se detectó un conflicto al recuperar la sesión.',
        });
      }

      // 4. Inicializar Estado Global y Sincronizar Motor
      const store = useSessionStore.getState();
      store.initialize();

      // 5. Vincular Hardware (Geofencing) con el Motor Lógico
      geofenceService.onEvent(async (event, identifier) => {
        try {
          const activeSession = sessionEngine.getActiveSession();
          
          // Ignorar eventos que no correspondan estrictamente a la sesión activa
          if (!activeSession || activeSession.id !== identifier) return;

          if (event === 'ENTER') await sessionEngine.onGeofenceEnter();
          if (event === 'EXIT') await sessionEngine.onGeofenceExit();
        } catch (err) {
          console.error('[Geofence Event Error]', err);
          useSessionStore.getState().updateSystemHealth({ geofenceActive: 'WARNING' });
        }
      });

      // 6. Verificar e inyectar estado de permisos nativos
      const permissionStatus = await geofenceService.getPermissionStatus();
      
      store.updateSystemHealth({
        locationPermission: permissionStatus === 'GRANTED' ? 'OK' : permissionStatus === 'DENIED' ? 'ERROR' : 'WARNING',
        backgroundLocation: permissionStatus === 'GRANTED' ? 'OK' : 'WARNING',
      });

      // 7. Re-registrar tarea de Geocerca si se recuperó sesión activa
      if (recoveryResult === 'RECOVERED' && permissionStatus === 'GRANTED') {
        const settings = settingsService.getSettings();
        const activeSession = sessionEngine.getActiveSession();
        
        if (activeSession && activeSession._lat != null && activeSession._lng != null) {
          await geofenceService.register({
            identifier: activeSession.id,
            latitude: activeSession._lat,
            longitude: activeSession._lng,
            radius: settings.geofenceRadius || 100,
          });
          store.updateSystemHealth({ geofenceActive: 'OK' });
          console.debug('[App Boot] Geocerca reactivada tras recuperación');
        }
      }

      // Finalizar pipeline de arranque
      setBootState('READY');
    } catch (err: any) {
      console.error('[CRITICAL_BOOT_FAILURE]', err);
      setBootError(err.message || 'Error grave en la conexión con la base de datos local.');
      setBootState('ERROR');
    }
  }, []);

  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  /**
   * Desmontar el Splash Screen cuando React Native termina de pintar la pantalla principal
   */
  const onLayoutRootView = useCallback(async () => {
    if (bootState !== 'BOOTING') {
      await SplashScreen.hideAsync();
    }
  }, [bootState]);

  // ── ESTADOS DE BLOQUEO DE RENDER ───────────────────────────

  if (bootState !== 'READY' && bootState !== 'ERROR') {
    return (
      <View style={styles.appContainer} onLayout={onLayoutRootView}>
        <StatusBar barStyle="light-content" backgroundColor={PALETTE.obsidian} translucent={false} />
        <BootScreen />
      </View>
    );
  }

  if (bootState === 'ERROR') {
    return (
      <View style={styles.appContainer} onLayout={onLayoutRootView}>
        <StatusBar barStyle="light-content" backgroundColor={PALETTE.obsidian} translucent={false} />
        <BootScreen error={bootError} />
      </View>
    );
  }

  // ── NAVEGACIÓN Y APLICACIÓN PRINCIPAL ──────────────────────

  const CustomDarkTheme: Theme = {
    dark: true,
    colors: {
      primary: PALETTE.mutedGold,
      background: PALETTE.obsidian,
      card: PALETTE.carbonMist,
      text: TEXT.primary,
      border: PALETTE.steelLine,
      notification: PALETTE.amberWarning,
    },
  };

  return (
    <GestureHandlerRootView style={styles.appContainer}>
      <SafeAreaProvider onLayout={onLayoutRootView}>
        <ToastProvider>
          <StatusBar
            barStyle="light-content"
            backgroundColor={PALETTE.obsidian}
            translucent={false}
          />
          <NavigationContainer theme={CustomDarkTheme}>
            <AppNavigator />
          </NavigationContainer>
        </ToastProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

// ── ESTILOS ─────────────────────────────────────────────────

const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
    backgroundColor: PALETTE.obsidian,
  },
});

const bootStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.obsidian,
    justifyContent: 'center',
    alignItems: 'center',
  },
  brand: {
    color: PALETTE.mutedGold,
    fontSize: 84,
    fontWeight: '800',
    letterSpacing: -4,
    fontFamily: 'System', // Cambiar a la fuente corporativa si aplica
  },
  brandSub: {
    color: TEXT.muted,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 8,
    textTransform: 'uppercase',
    marginTop: -12,
  },
  loadingBox: {
    marginTop: 80,
    alignItems: 'center',
  },
  loadingText: {
    color: TEXT.secondary,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2,
  },
  spinner: {
    marginTop: 24,
  },
  errorBox: {
    marginTop: 40,
    paddingHorizontal: 40,
    alignItems: 'center',
  },
  errorTitle: {
    color: PALETTE.deepRed,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 8,
  },
  errorText: {
    color: TEXT.secondary,
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 20,
  },
});
