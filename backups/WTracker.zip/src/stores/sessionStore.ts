// ============================================================
// STORE: sessionStore — Estado global reactivo (Zustand) CONSOLIDADO
// Versión: 2.0.0 (Workday Tracking Store Canónico V2.0)
// Fuente: Blueprint Pantalla Hoy & Matriz de Resiliencia
// Conecta: SessionEngineService ↔ GeofenceService ↔ SQLite ↔ UI Layer
// Responsabilidad: Puente reactivo para orquestar y propagar el estado de la jornada.
// ============================================================

import { create } from 'zustand';
import {
  Break,
  DestinationVisit,
  Session,
  SessionState,
  SystemHealth,
  Transfer,
} from '../types';
import {
  databaseService,
  geofenceService,
  sessionEngine,
  sessionRepository,
  settingsService,
  ToastService,
} from '../services';

let engineUnsubscribe: (() => void) | null = null;
let geofenceUnsubscribe: (() => void) | null = null;

export interface SessionStore {
  // ── ESTADO OPERATIVO Y RELACIONAL V2.0 ─────────────────────
  sessionState: SessionState;
  activeSession: Session | null;
  elapsedTime: string;
  currentDestination: string | null;
  visitedDestinations: DestinationVisit[];
  transfers: Transfer[];
  breaks: Break[];

  // ── INFRAESTRUCTURA & HISTORIAL ───────────────────────────
  systemHealth: SystemHealth;
  sessions: Session[];
  isLoadingSessions: boolean;
  pendingToast: { type: 'success' | 'info' | 'warning' | 'error'; text: string } | null;

  // ── BOOT & SYNC ───────────────────────────────────────────
  initialize: () => void;
  syncWithEngine: () => void;

  // ── CICLO DE VIDA DE JORNADA MULTI-DESTINO V2.0 ───────────
  startSession: (destination: string, alias?: string) => Promise<void>;
  confirmArrival: () => Promise<void>;
  startLunch: () => Promise<void>;
  endLunch: () => Promise<void>;
  startTransfer: (destination: string, alias?: string) => Promise<void>;
  completeTransfer: () => Promise<void>;
  finishWorkDay: (lunchMinutes: number) => Promise<void>;

  // ── UI HELPERS & COMPATIBILIDAD LEGACY ───────────────────
  validateForegroundExit: () => Promise<void>;
  confirmExit: () => Promise<void>;
  stayWorking: () => void;
  cancelSession: () => Promise<void>;
  addNote: (note: string) => Promise<void>;
  closeSession: (lunchMinutes: number) => Promise<void>;

  // ── HISTORIAL Y SALUD DE SISTEMA ──────────────────────────
  loadSessions: (silent?: boolean) => Promise<void>;
  deleteSession: (id: string) => Promise<void>;
  editSession: (id: string, patch: Partial<Session>) => Promise<void>;
  updateSystemHealth: (health: Partial<SystemHealth>) => void;
  clearPendingToast: () => void;
}

export const INITIAL_STORE_STATE = {
  sessionState: 'NO_INICIADA' as SessionState,
  activeSession: null as Session | null,
  elapsedTime: '00:00',
  currentDestination: null as string | null,
  visitedDestinations: [] as DestinationVisit[],
  transfers: [] as Transfer[],
  breaks: [] as Break[],
  sessions: [] as Session[],
  isLoadingSessions: false,
  pendingToast: null,
  systemHealth: {
    locationPermission: 'OK' as const,
    backgroundLocation: 'OK' as const,
    geofenceActive: 'OK' as const,
    lastValidationMinutes: 0,
    notificationsReady: 'OK' as const,
  },
};

export const useSessionStore = create<SessionStore>((set, get) => ({
  ...INITIAL_STORE_STATE,

  // ── BOOT / SUBSCRIPTION ───────────────────────────────────
  // Conecta SessionEngineService & GeofenceService → Zustand → UI
  initialize: () => {
    if (!engineUnsubscribe) {
      engineUnsubscribe = sessionEngine.subscribe((state, session) => {
        set({
          sessionState: state,
          activeSession: session,
          currentDestination: session?.destination ?? null,
          visitedDestinations: session?.visits ?? [],
          transfers: session?.transfers ?? [],
          breaks: session?.breaks ?? [],
          elapsedTime: session ? get().elapsedTime : '00:00',
        });
      });
    }

    if (!geofenceUnsubscribe) {
      geofenceUnsubscribe = geofenceService.onEvent(async (event, identifier) => {
        const activeSession = sessionEngine.getActiveSession();
        if (!activeSession || activeSession.id !== identifier) {
          return;
        }

        try {
          if (event === 'ENTER') {
            await sessionEngine.onGeofenceEnter();
          } else if (event === 'EXIT') {
            await sessionEngine.onGeofenceExit();
          }

          get().syncWithEngine();
        } catch (error) {
          console.error('[Geofence Event Handling Error]', error);
          ToastService.push({
            type: 'error',
            text: 'Error al procesar el evento de geocerca nativa.',
          });
        }
      });
    }

    get().syncWithEngine();
  },

  // Sincroniza manualmente el estado del store con el Engine Singleton
  syncWithEngine: () => {
    const activeSession = sessionEngine.getActiveSession();
    const sessionState = sessionEngine.getCurrentState();

    set({
      sessionState,
      activeSession: activeSession ? { ...activeSession } : null,
      currentDestination: activeSession?.destination ?? null,
      visitedDestinations: activeSession?.visits ?? [],
      transfers: activeSession?.transfers ?? [],
      breaks: activeSession?.breaks ?? [],
    });
  },

  // ── ACCIONES DE JORNADA MULTI-DESTINO V2.0 ────────────────

  startSession: async (destination, alias) => {
    const session = await sessionEngine.startSession({ destination, alias });

    let lat = session._lat;
    let lng = session._lng;

    // Fallback adicional si no hay coordenadas geocodificadas
    if (lat == null || lng == null) {
      const loc = await geofenceService.getCurrentLocation();
      if (loc) {
        lat = loc.lat;
        lng = loc.lng;
      }
    }

    if (lat != null && lng != null) {
      try {
        const settings = settingsService.getSettings();
        await geofenceService.register({
          identifier: session.id,
          latitude: lat,
          longitude: lng,
          radius: settings.geofenceRadius || 100,
        });

        get().updateSystemHealth({ geofenceActive: 'OK' });
        ToastService.push({
          type: 'success',
          text: 'Monitoreo de geocerca activado',
        });
      } catch (error) {
        console.warn('[Start Session Geofence Warning]', error);
        get().updateSystemHealth({ geofenceActive: 'WARNING' });
        ToastService.push({
          type: 'warning',
          text: 'Jornada iniciada. Verifica permisos de ubicación para monitoreo.',
        });
      }
    } else {
      get().updateSystemHealth({ geofenceActive: 'WARNING' });
      ToastService.push({
        type: 'warning',
        text: 'Jornada iniciada sin coordenadas espaciales.',
      });
    }

    get().syncWithEngine();
  },

  confirmArrival: async () => {
    await sessionEngine.confirmArrival();
    get().syncWithEngine();
    ToastService.push({
      type: 'success',
      text: 'Llegada a destino confirmada',
    });
  },

  startLunch: async () => {
    await sessionEngine.startLunch();
    get().syncWithEngine();
    ToastService.push({
      type: 'warning',
      text: 'Almuerzo / Pausa iniciada',
    });
  },

  endLunch: async () => {
    await sessionEngine.endLunch();
    get().syncWithEngine();
    ToastService.push({
      type: 'success',
      text: 'Regreso al trabajo reanudado',
    });
  },

  startTransfer: async (destination, alias) => {
    await sessionEngine.startTransfer(destination, alias);
    get().syncWithEngine();
    ToastService.push({
      type: 'info',
      text: `Traslado iniciado hacia: ${alias || destination}`,
    });
  },

  completeTransfer: async () => {
    await sessionEngine.completeTransfer();
    get().syncWithEngine();
    ToastService.push({
      type: 'success',
      text: 'Llegada a nuevo destino registrada',
    });
  },

  finishWorkDay: async (lunchMinutes) => {
    const active = get().activeSession;
    if (active) {
      await geofenceService.unregister(active.id).catch(() => {});
    }

    await sessionEngine.finishWorkDay(lunchMinutes);
    get().updateSystemHealth({ geofenceActive: 'WARNING' });
    get().syncWithEngine();

    ToastService.push({
      type: 'success',
      text: 'Jornada finalizada y consolidada con éxito',
    });
  },

  // Compatibilidad legacy que delega en finishWorkDay
  closeSession: async (lunchMinutes) => {
    await get().finishWorkDay(lunchMinutes);
  },

  // ── UI HELPERS & COMPATIBILIDAD ────────────────────────────

  validateForegroundExit: async () => {
    const previousState = sessionEngine.getCurrentState();
    await sessionEngine.validateForegroundExit();
    get().syncWithEngine();

    const currentState = sessionEngine.getCurrentState();
    get().updateSystemHealth({ lastValidationMinutes: 0 });

    if (previousState !== 'SALIDA' && currentState === 'SALIDA') {
      ToastService.push({
        type: 'warning',
        text: 'Salida del área de trabajo detectada',
      });
    }
  },

  confirmExit: async () => {
    const active = get().activeSession;
    if (active) {
      await geofenceService.unregister(active.id).catch(() => {});
    }

    await sessionEngine.confirmExit();
    get().updateSystemHealth({ geofenceActive: 'WARNING' });
    get().syncWithEngine();

    ToastService.push({
      type: 'success',
      text: 'Jornada cerrada correctamente',
    });
  },

  stayWorking: () => {
    sessionEngine.resumeFromExit();
    get().syncWithEngine();
    ToastService.push({
      type: 'info',
      text: 'Jornada reanudada',
    });
  },

  cancelSession: async () => {
    const active = get().activeSession;
    if (active) {
      await geofenceService.unregister(active.id).catch(() => {});
    }

    await sessionEngine.cancelSession();
    get().updateSystemHealth({ geofenceActive: 'WARNING' });
    get().syncWithEngine();

    ToastService.push({
      type: 'info',
      text: 'Jornada cancelada',
    });
  },

  addNote: async (note) => {
    await sessionEngine.addNote(note);
    get().syncWithEngine();
  },

  // ── HISTORY / PERSISTED SESSIONS ──────────────────────────

  loadSessions: async (silent = false) => {
    if (!silent) set({ isLoadingSessions: true });
    try {
      const allSessions = await sessionRepository.getAll();
      set({ sessions: allSessions, isLoadingSessions: false });
    } catch (error) {
      console.error('[Load Sessions Error]', error);
      set({ isLoadingSessions: false });
      ToastService.push({
        type: 'error',
        text: 'No se pudo cargar el historial de jornadas',
      });
    }
  },

  deleteSession: async (id) => {
    try {
      await sessionRepository.delete(id);
      set((state) => ({
        sessions: state.sessions.filter((session) => session.id !== id),
      }));
      ToastService.push({
        type: 'success',
        text: 'Jornada eliminada',
      });
    } catch (error: any) {
      ToastService.push({
        type: 'error',
        text: error?.message || 'Error al eliminar jornada',
      });
    }
  },

  editSession: async (id, patch) => {
    try {
      const updated = await sessionRepository.update(id, {
        ...patch,
        integrityType: 'MANUAL',
      });
      set((state) => ({
        sessions: state.sessions.map((session) => (session.id === id ? updated : session)),
      }));
      ToastService.push({
        type: 'success',
        text: 'Ajuste manual aplicado',
      });
    } catch (error: any) {
      ToastService.push({
        type: 'error',
        text: error?.message || 'Error al guardar ajuste manual',
      });
    }
  },

  // ── SYSTEM HEALTH & TOASTS ────────────────────────────────

  updateSystemHealth: (health) => {
    set((state) => ({
      systemHealth: {
        ...state.systemHealth,
        ...health,
      },
    }));
  },

  clearPendingToast: () => {
    set({ pendingToast: null });
  },
}));
