// ============================================================
// W TRACKER — TIPOS GLOBALES Y CONTRATOS DE DOMINIO V2.0 (CONSOLIDADO)
// Versión: 2.0.0 (Workday Tracking Platform)
// Fuente: Guía Técnica & Especificación Arquitectónica UI/UX
// Responsabilidad: Corazón contractual de la aplicación.
// ============================================================

// ── 1. UI STATUS TYPES ──────────────────────────────────────────

/**
 * Estados visuales para indicadores (Pills) y Timelines.
 */
export type PillStatus =
  | 'idle'
  | 'pending'
  | 'active'
  | 'warning'
  | 'error'
  | 'closed';

/**
 * Indicadores de integridad forense para auditoría de nómina.
 */
export type IntegrityType =
  | 'VALID'    // Registro automático íntegro
  | 'MANUAL'   // Editado por el usuario
  | 'AUTO'     // Cerrado por el sistema por abandono de jornada
  | 'CONFLICT'; // Detectado Clock Drift o solapamiento de horarios

/**
 * Máquina de estados de la jornada laboral V2.
 */
export type SessionState =
  | 'NO_INICIADA'
  | 'ESPERANDO'
  | 'TRASLADO'
  | 'ACTIVA'
  | 'SALIDA'
  | 'PAUSADA'  // Estado de almuerzo/descanso
  | 'CERRADA';

// ── 2. DOMINIO RELACIONAL DE JORNADA (V2.0) ────────────────────

/**
 * Registro de estancia en un destino físico de trabajo.
 */
export interface DestinationVisit {
  id: string;
  sessionId?: string;
  destination: string;
  alias?: string;
  enterTime: string; // HH:MM
  exitTime?: string; // HH:MM
  lat?: number;
  lng?: number;
}

/**
 * Representa traslados entre destinos laborales.
 */
export interface Transfer {
  id: string;
  sessionId?: string;
  originDestination: string;
  targetDestination: string;
  destination?: string; // Alias de conveniencia V2
  startTime: string;    // HH:MM
  endTime?: string;     // HH:MM
}

/**
 * Modela pausas o almuerzos.
 */
export interface Break {
  id: string;
  sessionId?: string;
  startTime: string; // HH:MM
  endTime?: string;  // HH:MM
  durationMinutes: number;
}

// ── 3. SESSION & WORKDAY DOMAIN ────────────────────────────────

export type TimelineEvent = {
  id: string;
  timestamp: string;
  description: string;
  status: PillStatus;
  metadata?: string; // JSON con datos contextuales (GPS, precisión, etc.)
};

/**
 * Entidad base de persistencia y visualización.
 * Mantiene compatibilidad total con V1 y V2.
 */
export interface Session {
  id: string;
  date: string; // YYYY-MM-DD
  destination: string;
  alias?: string;
  startTime: string;
  endTime: string;
  totalHours: number;
  lunchDeductedMinutes: number;
  overtimeHours: number;
  snapshotRate: number;
  totalEarnings: number;
  integrityType: IntegrityType;
  notes?: string;
  state: SessionState;
  timelineEvents: TimelineEvent[];

  // Relaciones V2 (Opcionales para flexibilidad de memoria y persistencia)
  visits?: DestinationVisit[];
  transfers?: Transfer[];
  breaks?: Break[];

  // Acumuladores de alta precisión V2
  paidMinutes?: number;
  pauseMinutes?: number;
  transferMinutes?: number;

  /** Campos internos para monitoreo de geocerca y resiliencia WAL */
  _lat?: number;
  _lng?: number;
  _deviceStatus?: string;
}

/**
 * Contrato estricto para una jornada laboral V2 completa con colecciones garantizadas.
 */
export interface WorkDay extends Session {
  visits: DestinationVisit[];
  transfers: Transfer[];
  breaks: Break[];
}

// ── 4. SETTINGS & GOVERNMENT ────────────────────────────────────

export interface UserSettings {
  name: string;
  hourlyRate: number;
  reportEmail: string;
  baseWorkHour: string;
  overtimeMultiplier: number;
  lunchDiscountMinutes: number;
  geofenceRadius: number;

  // Ajustes de gobernabilidad V2
  multiDestination?: boolean;
  paidTransfers?: boolean;
  destinationLimit?: number;

  // Preferencias operativas
  dailyReminder: boolean;
  workdayAlerts: boolean;
  reportReady: boolean;
  language: 'es' | 'en';
}

// ── 5. REPORTING ───────────────────────────────────────────────

export interface WeeklySummary {
  periodLabel: string;
  totalHours: number;
  totalEarnings: number;
  sessionCount: number;
  manualAdjustments: number;
  overtimeHours: number;
  baseEarnings: number;
  overtimeEarnings: number;
  baseRate: number;
  overtimeMultiplier: number;
}

export interface PDFReport {
  periodLabel: string;
  weekStart: string;
  weekEnd: string;
  generatedAt: string;
  summary: WeeklySummary;
  sessions: Session[];
}

// ── 6. MODAL PAYLOADS ──────────────────────────────────────────

export interface DailySetupPayload {
  destination: string;
  alias?: string;
}

export interface LunchModalPayload {
  minutes: 0 | 30 | 45 | 60;
}

// ── 7. NAVIGATION TYPES ────────────────────────────────────────

export type RootTabParamList = {
  Hoy: undefined;
  Historial: undefined;
  Reportes: undefined;
  Ajustes: undefined;
};

export type RootStackParamList = {
  MainTabs: undefined;
};

// ── 8. SYSTEM HEALTH ───────────────────────────────────────────

export type SystemHealthStatus = 'OK' | 'WARNING' | 'ERROR';

export interface SystemHealth {
  locationPermission: SystemHealthStatus;
  backgroundLocation: SystemHealthStatus;
  geofenceActive: SystemHealthStatus;
  notificationsReady: SystemHealthStatus;
  lastValidationMinutes?: number;
}
