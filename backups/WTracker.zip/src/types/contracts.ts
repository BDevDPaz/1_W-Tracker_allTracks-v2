// ============================================================
// W TRACKER — CONTRATOS DE API Y SERVICIOS INTERNOS V2.0 (CONSOLIDADO)
// Versión: 2.0.0 (Workday Tracking Platform)
// Fuente: Rediseño del Dominio y Contratos de Datos V2
// Responsabilidad: Modelos de persistencia (SQLite) + Contratos de servicios
// ============================================================

import type {
  Break,
  DestinationVisit,
  IntegrityType,
  PDFReport,
  Session,
  SessionState,
  SystemHealth,
  SystemHealthStatus,
  TimelineEvent,
  Transfer,
  UserSettings,
  WeeklySummary,
} from './index';

export type {
  Break,
  DestinationVisit,
  IntegrityType,
  PDFReport,
  Session,
  SessionState,
  SystemHealth,
  SystemHealthStatus,
  TimelineEvent,
  Transfer,
  UserSettings,
  WeeklySummary,
};

// ═══════════════════════════════════════════════════════════
// 1. DATABASE SCHEMA CONTRACTS (SQLite Mirror)
// ═══════════════════════════════════════════════════════════

/**
 * Registro plano de Sesión/Jornada en SQLite (v2.0)
 */
export interface DB_Session {
  id: string;
  date: string;
  destination: string;
  alias: string | null;
  start_time: string;
  end_time: string | null;
  total_hours: number;
  lunch_deducted_minutes: number;
  overtime_hours: number;
  snapshot_rate: number;
  total_earnings: number;
  integrity_type: IntegrityType;
  notes: string | null;
  state: SessionState;

  // Acumuladores de tiempo en minutos V2.0
  paid_minutes: number;
  pause_minutes: number;
  transfer_minutes: number;
  destination_count: number;

  _lat: number | null;
  _lng: number | null;
  _device_status: string | null;
  created_at: string;
  updated_at: string;
}

/**
 * Registro de Visita Operativa en SQLite (V2.0 Relacional)
 */
export interface DB_DestinationVisit {
  id: string;
  session_id: string;
  destination: string;
  alias: string | null;
  enter_time: string;
  exit_time: string | null;
  lat: number | null;
  lng: number | null;
}

/**
 * Registro de Traslado en SQLite (V2.0 Relacional)
 */
export interface DB_Transfer {
  id: string;
  session_id: string;
  origin_destination: string;
  target_destination: string;
  start_time: string;
  end_time: string | null;
}

/**
 * Registro de Pausa/Almuerzo en SQLite (V2.0 Relacional)
 */
export interface DB_Break {
  id: string;
  session_id: string;
  start_time: string;
  end_time: string | null;
  duration_minutes: number;
}

/**
 * Hito del Timeline de Sesión en SQLite
 */
export interface DB_TimelineEvent {
  id: string;
  session_id: string;
  timestamp: string;
  description: string;
  status: string;
  sequence: number;
  metadata?: string | null; // Metadatos V2.0 (ej. Coordenadas GPS)
}

/**
 * Entrada Write-Ahead Log para Resiliencia ante cierres forzados
 */
export interface DB_WALEntry {
  id: string;
  session_id: string;
  event_type: string;
  payload: string;
  created_at: string;
  synced: 0 | 1;
}

/**
 * Registro de Configuración Canónica en SQLite
 */
export interface DB_Settings {
  id: string;
  name: string;
  hourly_rate: number;
  report_email: string;
  base_work_hour: string;
  overtime_multiplier: number;
  lunch_discount_minutes: number;
  geofence_radius: number;
  daily_reminder: 0 | 1;
  workday_alerts: 0 | 1;
  report_ready: 0 | 1;
  language: 'es' | 'en';

  // Ajustes de gobernabilidad V2.0
  multi_destination: 0 | 1;
  paid_transfers: 0 | 1;
  destination_limit: number;

  updated_at: string;
}

// ═══════════════════════════════════════════════════════════
// 2. SESSION ENGINE CONTRACT (Workday Engine V2.0)
// ═══════════════════════════════════════════════════════════

export interface ISessionEngineService {
  getCurrentState(): SessionState;
  getActiveSession(): Session | null;

  // Ciclo V2.0
  startSession(payload: { destination: string; alias?: string }): Promise<Session>;
  confirmArrival(): Promise<void>;

  // Transiciones Multi-Destino y Pausas V2.0
  startLunch(): Promise<void>;
  endLunch(): Promise<void>;
  startTransfer(destination: string, alias?: string): Promise<void>;
  completeTransfer(): Promise<void>;
  finishWorkDay(lunchMinutes: number): Promise<Session>;

  // Compatibilidad V1 & Métodos Auxiliares
  closeSession(lunchMinutes: number): Promise<Session>;
  confirmExit(): Promise<Session>;
  cancelSession(): Promise<void>;
  addNote(note: string): Promise<void>;

  // Geocercas & Foreground Validation
  onGeofenceEnter(): Promise<void>;
  onGeofenceExit(): Promise<void>;
  validateForegroundExit(): Promise<void>;
  resumeFromExit(): void;

  // Resiliencia & WAL
  rehydrateFromWAL(): Promise<'OK' | 'RECOVERED' | 'CONFLICT'>;
  detectTimeDrift(currentTimestamp: number, previousTimestamp: number): boolean;
  subscribe(listener: (state: SessionState, session: Session | null) => void): () => void;
  reset?(): void;
}

// ═══════════════════════════════════════════════════════════
// 3. REPOSITORY CONTRACT (V2.0)
// ═══════════════════════════════════════════════════════════

export interface ISessionRepository {
  getAll(): Promise<Session[]>;
  getById(id: string): Promise<Session | null>;
  getByPeriod(startDate: string, endDate: string): Promise<Session[]>;
  create(session: Session): Promise<Session>;
  update(id: string, patch: Partial<Session>): Promise<Session>;
  delete(id: string): Promise<void>;
  getWeeklySummary(weekStart: string, weekEnd: string): Promise<WeeklySummary>;

  // Métodos Sub-relacionales V2.0
  getVisits(sessionId: string): Promise<DestinationVisit[]>;
  getTransfers(sessionId: string): Promise<Transfer[]>;
  getBreaks(sessionId: string): Promise<Break[]>;
}

// ═══════════════════════════════════════════════════════════
// 4. GEOFENCE CONTRACTS (Dynamic Geofencing V2.0)
// ═══════════════════════════════════════════════════════════

export interface GeofenceConfig {
  latitude: number;
  longitude: number;
  radius: number;
  identifier: string;
}

export type GeofenceEvent = 'ENTER' | 'EXIT';

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface ExitValidationResult {
  isOutside: boolean;
  distanceMeters: number;
  radiusMeters: number;
}

export interface IGeofenceService {
  register(config: GeofenceConfig): Promise<void>;
  unregister(identifier: string): Promise<void>;

  // Sobrecarga de firmas para reconfigurar geocercas activas
  replaceGeofence(config: GeofenceConfig): Promise<void>;
  replaceGeofence(oldIdentifier: string, newConfig: GeofenceConfig): Promise<void>;

  registerNextDestination(address: string, sessionId?: string): Promise<Coordinates | null | void>;

  onEvent(callback: (event: GeofenceEvent, identifier: string) => void): () => void;
  getCurrentLocation(): Promise<Coordinates | null>;
  geocodeAddress(address: string): Promise<Coordinates | null>;
  validateExitByCurrentLocation(params: { center: Coordinates; radiusMeters: number }): Promise<ExitValidationResult | null>;
  getPermissionStatus(): Promise<'GRANTED' | 'DENIED' | 'NOT_DETERMINED'>;
  requestPermissions(): Promise<boolean>;
}

// ═══════════════════════════════════════════════════════════
// 5. OTHER SERVICE CONTRACTS
// ═══════════════════════════════════════════════════════════

export interface IPDFService {
  generate(report: PDFReport): Promise<string>;
  share(filePath: string): Promise<void>;
  sendByEmail(filePath: string, to: string): Promise<void>;
  preview(filePath: string): Promise<void>;
}

export interface ISettingsService {
  load(): Promise<UserSettings>;
  save(settings: UserSettings): Promise<void>;
  getSettings(): UserSettings;
  getSnapshotRate(): Promise<number>;
  clearCache(): void;
}

// ── TOAST NOTIFICATIONS ─────────────────────────────────────

export type ToastType = 'success' | 'info' | 'warning' | 'error';

export interface ToastMessage {
  id: string;
  type: ToastType;
  text: string;
  durationMs?: number;
}

export interface IToastQueue {
  push(msg: Omit<ToastMessage, 'id'>): void;
  clear(): void;
}

// ── FILTERS & RESILIENCE ────────────────────────────────────

export type SessionFilter =
  | 'TODO'
  | 'SEMANA'
  | 'MES'
  | 'AJUSTADAS'
  | 'AUTO_CERRADAS'
  | 'PENDIENTES';

export const FILTER_LABELS: Record<SessionFilter, string> = {
  TODO: 'Todo',
  SEMANA: 'Semana',
  MES: 'Mes',
  AJUSTADAS: 'Ajustadas',
  AUTO_CERRADAS: 'Auto cerradas',
  PENDIENTES: 'Pendientes',
};

export type RehydrationResult = 'OK' | 'RECOVERED' | 'CONFLICT';
