// ============================================================
// W TRACKER — BARREL DE SERVICIOS CANÓNICO V2.0 (CONSOLIDADO)
// Ubicación: src/services/index.ts
// Fuente: Guía Técnica - Arquitectura de Capas
// Responsabilidad: Punto único de exportación para la infraestructura
// ============================================================

export * from './database/DatabaseService';
export * from './settings/SettingsService';
export * from './sessionEngine/SessionEngineService';
export * from './geofence/GeofenceService';
export * from './pdf/PDFService';
export * from './toast/ToastService';

// /**
// * 1. PERSISTENCIA Y REPOSITORIOS
// */
//export {
//  DatabaseService,
//  databaseService,
//  DB_SCHEMA,
//  SessionRepository,
//  sessionRepository,
//} from './DatabaseService';
//
///**
// * 2. GOBERNANZA Y CONFIGURACIÓN
// */
//export {
//  SettingsService,
//  settingsService,
//} from './SettingsService';
//
///**
// * 3. MOTORES OPERATIVOS (CORE)
// */
//export {
//  SessionEngineService,
//  sessionEngine,
//} from './SessionEngineService';
//
///**
// * 4. SERVICIOS NATIVOS Y HARDWARE
// */
//export {
//  GeofenceService,
//  geofenceService,
//} from './GeofenceService';
//
///**
// * 5. COMUNICACIÓN Y AUDITORÍA
// */
//export {
//  PDFService,
//  pdfService,
//} from './PDFService';
//
//export {
//  ToastProvider,
//  ToastService,
//  useToast,
//} from './ToastService';
