// ============================================================
// SERVICE: DatabaseService — Capa de persistencia SQLite (CONSOLIDADO)
// Versión: 2.0.0 (Workday Tracking Platform)
// Fuente: Matriz de Resiliencia — Sección 3.1 (WAL + SQLite)
// Contratos de API: DB_Session, DB_TimelineEvent, DB_WALEntry, DB_Settings
// ============================================================

import * as Crypto from 'expo-crypto';
import * as SQLite from 'expo-sqlite';
import {
  Break,
  DestinationVisit,
  Session,
  TimelineEvent,
  Transfer,
  WeeklySummary,
} from '../../types/contracts';
import { ISessionRepository } from '../../types/contracts';

// Instancia única de base de datos SQLite
let db: SQLite.SQLiteDatabase | null = null;

export const DB_SCHEMA = `
  -- PRAGMA Habilitar claves foráneas
  PRAGMA foreign_keys = ON;

  -- Tabla principal de sesiones (Jornadas V2.0)
  CREATE TABLE IF NOT EXISTS sessions (
    id                       TEXT PRIMARY KEY,
    date                     TEXT NOT NULL,
    destination              TEXT NOT NULL,
    alias                    TEXT,
    start_time               TEXT NOT NULL,
    end_time                 TEXT,
    total_hours              REAL DEFAULT 0,
    lunch_deducted_minutes   INTEGER DEFAULT 0,
    overtime_hours           REAL DEFAULT 0,
    snapshot_rate            REAL NOT NULL,
    total_earnings           REAL DEFAULT 0,
    integrity_type           TEXT DEFAULT 'VALID',
    notes                    TEXT,
    state                    TEXT DEFAULT 'NO_INICIADA',
    paid_minutes             INTEGER DEFAULT 0,
    pause_minutes            INTEGER DEFAULT 0,
    transfer_minutes         INTEGER DEFAULT 0,
    destination_count        INTEGER DEFAULT 1,
    _lat                     REAL,
    _lng                     REAL,
    _device_status           TEXT,
    created_at               TEXT NOT NULL,
    updated_at               TEXT NOT NULL
  );

  -- Tabla de destinos visitados (V2.0 Relacional)
  CREATE TABLE IF NOT EXISTS destination_visits (
    id           TEXT PRIMARY KEY,
    session_id   TEXT NOT NULL,
    destination  TEXT NOT NULL,
    alias        TEXT,
    enter_time   TEXT NOT NULL,
    exit_time    TEXT,
    lat          REAL,
    lng          REAL,
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
  );

  -- Tabla de traslados entre destinos (V2.0 Relacional)
  CREATE TABLE IF NOT EXISTS transfers (
    id                  TEXT PRIMARY KEY,
    session_id          TEXT NOT NULL,
    origin_destination  TEXT NOT NULL,
    target_destination  TEXT NOT NULL,
    start_time          TEXT NOT NULL,
    end_time            TEXT,
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
  );

  -- Tabla de descansos / almuerzos (V2.0 Relacional)
  CREATE TABLE IF NOT EXISTS breaks (
    id                TEXT PRIMARY KEY,
    session_id        TEXT NOT NULL,
    start_time        TEXT NOT NULL,
    end_time          TEXT,
    duration_minutes  INTEGER DEFAULT 0,
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
  );

  -- Hitos de cada sesión
  CREATE TABLE IF NOT EXISTS timeline_events (
    id            TEXT PRIMARY KEY,
    session_id    TEXT NOT NULL,
    timestamp     TEXT NOT NULL,
    description   TEXT NOT NULL,
    status        TEXT NOT NULL,
    sequence      INTEGER NOT NULL,
    metadata      TEXT,
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
  );

  -- Write-Ahead Log para resiliencia ante cierres inesperados del OS
  CREATE TABLE IF NOT EXISTS wal_log (
    id          TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL,
    event_type  TEXT NOT NULL,
    payload     TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    synced      INTEGER DEFAULT 0
  );

  -- Configuración del usuario: 1 fila canónica (V2.0)
  CREATE TABLE IF NOT EXISTS settings (
    id                       TEXT PRIMARY KEY DEFAULT 'user_settings',
    name                     TEXT DEFAULT '',
    hourly_rate              REAL DEFAULT 20,
    report_email             TEXT DEFAULT '',
    base_work_hour           TEXT DEFAULT '06:00',
    overtime_multiplier      REAL DEFAULT 1.5,
    lunch_discount_minutes   INTEGER DEFAULT 30,
    geofence_radius          INTEGER DEFAULT 100,
    daily_reminder           INTEGER DEFAULT 1,
    workday_alerts           INTEGER DEFAULT 1,
    report_ready             INTEGER DEFAULT 1,
    language                 TEXT DEFAULT 'es',
    multi_destination        INTEGER DEFAULT 0,
    paid_transfers           INTEGER DEFAULT 1,
    destination_limit        INTEGER DEFAULT 5,
    updated_at               TEXT NOT NULL
  );

  -- Índices para optimización de consultas
  CREATE INDEX IF NOT EXISTS idx_sessions_date ON sessions(date);
  CREATE INDEX IF NOT EXISTS idx_sessions_state ON sessions(state);
  CREATE INDEX IF NOT EXISTS idx_wal_synced ON wal_log(synced);
  CREATE INDEX IF NOT EXISTS idx_timeline_session ON timeline_events(session_id);
  CREATE INDEX IF NOT EXISTS idx_visits_session ON destination_visits(session_id);
  CREATE INDEX IF NOT EXISTS idx_transfers_session ON transfers(session_id);
  CREATE INDEX IF NOT EXISTS idx_breaks_session ON breaks(session_id);
`;

export class DatabaseService {
  /**
   * Inicializa la conexión a la base de datos y ejecuta la migración de esquema.
   */
  static async initialize(): Promise<void> {
    if (!db) {
      db = await SQLite.openDatabaseAsync('wtracker.db');
    }

    // 1. Configuración de sesión SQLite
    await db.execAsync('PRAGMA foreign_keys = ON;');

    // 2. Crear esquema base
    await db.execAsync(DB_SCHEMA);

    // 3. Migraciones preventivas al vuelo (hot-migrations)
    const hotMigrations = [
      'ALTER TABLE sessions ADD COLUMN paid_minutes INTEGER DEFAULT 0;',
      'ALTER TABLE sessions ADD COLUMN pause_minutes INTEGER DEFAULT 0;',
      'ALTER TABLE sessions ADD COLUMN transfer_minutes INTEGER DEFAULT 0;',
      'ALTER TABLE sessions ADD COLUMN destination_count INTEGER DEFAULT 1;',
      'ALTER TABLE timeline_events ADD COLUMN metadata TEXT;',
      'ALTER TABLE settings ADD COLUMN multi_destination INTEGER DEFAULT 0;',
      'ALTER TABLE settings ADD COLUMN paid_transfers INTEGER DEFAULT 1;',
      'ALTER TABLE settings ADD COLUMN destination_limit INTEGER DEFAULT 5;',
    ];

    for (const migrationSql of hotMigrations) {
      try {
        await db.execAsync(migrationSql);
      } catch (_) {
        // Ignorar error si la columna ya existe
      }
    }
  }

  static getDb(): SQLite.SQLiteDatabase {
    if (!db) {
      throw new Error(
        'DatabaseService no ha sido inicializado. Ejecuta DatabaseService.initialize() previamente.'
      );
    }
    return db;
  }

  public async initDB(): Promise<void> {
    return DatabaseService.initialize();
  }
}

// ── REPOSITORY IMPLEMENTATION ───────────────────────────────

export class SessionRepository implements ISessionRepository {
  private async getDatabase(): Promise<SQLite.SQLiteDatabase> {
    return DatabaseService.getDb();
  }

  async getAll(): Promise<Session[]> {
    const database = await this.getDatabase();
    const rows = await database.getAllAsync<any>(
      'SELECT * FROM sessions ORDER BY date DESC, start_time DESC'
    );
    const sessions: Session[] = [];
    for (const row of rows) {
      const events = await this._getTimelineEvents(database, row.id);
      const session = this._mapRowToSession(row, events);
      session.visits = await this.getVisits(row.id);
      session.transfers = await this.getTransfers(row.id);
      session.breaks = await this.getBreaks(row.id);
      sessions.push(session);
    }
    return sessions;
  }

  async getById(id: string): Promise<Session | null> {
    const database = await this.getDatabase();
    const row = await database.getFirstAsync<any>(
      'SELECT * FROM sessions WHERE id = ?',
      [id]
    );
    if (!row) return null;

    const events = await this._getTimelineEvents(database, id);
    const session = this._mapRowToSession(row, events);
    session.visits = await this.getVisits(id);
    session.transfers = await this.getTransfers(id);
    session.breaks = await this.getBreaks(id);
    return session;
  }

  async getByPeriod(startDate: string, endDate: string): Promise<Session[]> {
    const database = await this.getDatabase();
    const rows = await database.getAllAsync<any>(
      "SELECT * FROM sessions WHERE date >= ? AND date <= ? AND state = 'CERRADA' ORDER BY date DESC, start_time DESC",
      [startDate, endDate]
    );
    const sessions: Session[] = [];
    for (const row of rows) {
      const events = await this._getTimelineEvents(database, row.id);
      const session = this._mapRowToSession(row, events);
      session.visits = await this.getVisits(row.id);
      session.transfers = await this.getTransfers(row.id);
      session.breaks = await this.getBreaks(row.id);
      sessions.push(session);
    }
    return sessions;
  }

  async create(sessionData: Session): Promise<Session> {
    const database = await this.getDatabase();
    const now = new Date().toISOString();

    const paid_minutes = (sessionData as any).paid_minutes ?? sessionData.paidMinutes ?? 0;
    const pause_minutes = (sessionData as any).pause_minutes ?? sessionData.pauseMinutes ?? 0;
    const transfer_minutes = (sessionData as any).transfer_minutes ?? sessionData.transferMinutes ?? 0;
    const destination_count = (sessionData as any).destination_count ?? sessionData.visits?.length ?? 1;

    await database.runAsync(
      `INSERT INTO sessions (
        id, date, destination, alias, start_time, end_time, total_hours,
        lunch_deducted_minutes, overtime_hours, snapshot_rate, total_earnings,
        integrity_type, notes, state, paid_minutes, pause_minutes, transfer_minutes,
        destination_count, _lat, _lng, _device_status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        sessionData.id,
        sessionData.date,
        sessionData.destination,
        sessionData.alias || null,
        sessionData.startTime,
        sessionData.endTime || null,
        sessionData.totalHours ?? 0,
        sessionData.lunchDeductedMinutes ?? 0,
        sessionData.overtimeHours ?? 0,
        sessionData.snapshotRate,
        sessionData.totalEarnings ?? 0,
        sessionData.integrityType ?? 'VALID',
        sessionData.notes || null,
        sessionData.state ?? 'NO_INICIADA',
        paid_minutes,
        pause_minutes,
        transfer_minutes,
        destination_count,
        sessionData._lat || null,
        sessionData._lng || null,
        sessionData._deviceStatus || null,
        now,
        now,
      ]
    );

    if (sessionData.timelineEvents && sessionData.timelineEvents.length > 0) {
      await this._replaceTimelineEvents(database, sessionData.id, sessionData.timelineEvents);
    }
    if (sessionData.visits && sessionData.visits.length > 0) {
      await this._replaceVisits(database, sessionData.id, sessionData.visits);
    }
    if (sessionData.transfers && sessionData.transfers.length > 0) {
      await this._replaceTransfers(database, sessionData.id, sessionData.transfers);
    }
    if (sessionData.breaks && sessionData.breaks.length > 0) {
      await this._replaceBreaks(database, sessionData.id, sessionData.breaks);
    }

    const created = await this.getById(sessionData.id);
    if (!created) {
      throw new Error(`Error recuperando sesión creada: ${sessionData.id}`);
    }
    return created;
  }

  async update(id: string, patch: Partial<Session>): Promise<Session> {
    const database = await this.getDatabase();
    const now = new Date().toISOString();

    const fields: string[] = [];
    const values: any[] = [];

    if (patch.date !== undefined) { fields.push('date = ?'); values.push(patch.date); }
    if (patch.destination !== undefined) { fields.push('destination = ?'); values.push(patch.destination); }
    if (patch.alias !== undefined) { fields.push('alias = ?'); values.push(patch.alias || null); }
    if (patch.startTime !== undefined) { fields.push('start_time = ?'); values.push(patch.startTime); }
    if (patch.endTime !== undefined) { fields.push('end_time = ?'); values.push(patch.endTime || null); }
    if (patch.totalHours !== undefined) { fields.push('total_hours = ?'); values.push(patch.totalHours); }
    if (patch.lunchDeductedMinutes !== undefined) { fields.push('lunch_deducted_minutes = ?'); values.push(patch.lunchDeductedMinutes); }
    if (patch.overtimeHours !== undefined) { fields.push('overtime_hours = ?'); values.push(patch.overtimeHours); }
    if (patch.totalEarnings !== undefined) { fields.push('total_earnings = ?'); values.push(patch.totalEarnings); }
    if (patch.integrityType !== undefined) { fields.push('integrity_type = ?'); values.push(patch.integrityType); }
    if (patch.notes !== undefined) { fields.push('notes = ?'); values.push(patch.notes || null); }
    if (patch.state !== undefined) { fields.push('state = ?'); values.push(patch.state); }
    if (patch._lat !== undefined) { fields.push('_lat = ?'); values.push(patch._lat || null); }
    if (patch._lng !== undefined) { fields.push('_lng = ?'); values.push(patch._lng || null); }
    if (patch._deviceStatus !== undefined) { fields.push('_device_status = ?'); values.push(patch._deviceStatus || null); }

    const dbPatch = patch as any;
    if (dbPatch.paid_minutes !== undefined || patch.paidMinutes !== undefined) {
      fields.push('paid_minutes = ?');
      values.push(dbPatch.paid_minutes ?? patch.paidMinutes);
    }
    if (dbPatch.pause_minutes !== undefined || patch.pauseMinutes !== undefined) {
      fields.push('pause_minutes = ?');
      values.push(dbPatch.pause_minutes ?? patch.pauseMinutes);
    }
    if (dbPatch.transfer_minutes !== undefined || patch.transferMinutes !== undefined) {
      fields.push('transfer_minutes = ?');
      values.push(dbPatch.transfer_minutes ?? patch.transferMinutes);
    }

    fields.push('updated_at = ?');
    values.push(now);

    if (fields.length > 0) {
      values.push(id);
      await database.runAsync(
        `UPDATE sessions SET ${fields.join(', ')} WHERE id = ?`,
        values
      );
    }

    if (patch.timelineEvents !== undefined) {
      await this._replaceTimelineEvents(database, id, patch.timelineEvents);
    }
    if (patch.visits !== undefined) {
      await this._replaceVisits(database, id, patch.visits);
    }
    if (patch.transfers !== undefined) {
      await this._replaceTransfers(database, id, patch.transfers);
    }
    if (patch.breaks !== undefined) {
      await this._replaceBreaks(database, id, patch.breaks);
    }

    const updated = await this.getById(id);
    if (!updated) {
      throw new Error(`Error recuperando sesión actualizada: ${id}`);
    }
    return updated;
  }

  async delete(id: string): Promise<void> {
    const database = await this.getDatabase();
    await database.runAsync('DELETE FROM sessions WHERE id = ?', [id]);
  }

  async getWeeklySummary(weekStart: string, weekEnd: string): Promise<WeeklySummary> {
    const database = await this.getDatabase();
    const rows = await database.getAllAsync<any>(
      `SELECT * FROM sessions
       WHERE date >= ? AND date <= ? AND state = 'CERRADA'`,
      [weekStart, weekEnd]
    );

    let totalHours = 0;
    let totalEarnings = 0;
    let sessionCount = rows.length;
    let manualAdjustments = 0;
    let overtimeHours = 0;
    let baseEarnings = 0;
    let overtimeEarnings = 0;

    const settingsRow = await database.getFirstAsync<any>(
      "SELECT hourly_rate, overtime_multiplier FROM settings WHERE id = 'user_settings'"
    );
    const baseRate = settingsRow ? Number(settingsRow.hourly_rate ?? 20) : 20;
    const overtimeMultiplier = settingsRow ? Number(settingsRow.overtime_multiplier ?? 1.5) : 1.5;

    for (const row of rows) {
      totalHours += Number(row.total_hours ?? 0);
      totalEarnings += Number(row.total_earnings ?? 0);
      overtimeHours += Number(row.overtime_hours ?? 0);

      if (row.integrity_type === 'MANUAL') {
        manualAdjustments++;
      }

      const sRate = Number(row.snapshot_rate ?? baseRate);
      const sOvertime = Number(row.overtime_hours ?? 0);
      const sTotalHours = Number(row.total_hours ?? 0);
      const sBaseHours = Math.max(0, sTotalHours - sOvertime);

      const sBaseEarnings = sBaseHours * sRate;
      const sOvertimeEarnings = sOvertime * sRate * overtimeMultiplier;

      baseEarnings += sBaseEarnings;
      overtimeEarnings += sOvertimeEarnings;
    }

    const periodLabel = `${weekStart} - ${weekEnd}`;

    return {
      periodLabel,
      totalHours: Number(totalHours.toFixed(2)),
      totalEarnings: Number(totalEarnings.toFixed(2)),
      sessionCount,
      manualAdjustments,
      overtimeHours: Number(overtimeHours.toFixed(2)),
      baseEarnings: Number(baseEarnings.toFixed(2)),
      overtimeEarnings: Number(overtimeEarnings.toFixed(2)),
      baseRate,
      overtimeMultiplier,
    };
  }

  async getSnapshotRateForSession(sessionId: string): Promise<number> {
    const database = await this.getDatabase();
    const row = await database.getFirstAsync<any>(
      'SELECT snapshot_rate FROM sessions WHERE id = ?',
      [sessionId]
    );
    return row ? Number(row.snapshot_rate) : 20;
  }

  async checkOverlap(
    excludeId: string,
    date: string,
    newStart: string,
    newEnd: string
  ): Promise<boolean> {
    const database = await this.getDatabase();
    const rows = await database.getAllAsync<any>(
      "SELECT start_time, end_time FROM sessions WHERE date = ? AND id != ? AND state = 'CERRADA'",
      [date, excludeId]
    );

    const toMinutes = (t: string): number => {
      const parts = t.split(':');
      if (parts.length !== 2) return 0;
      return Number(parts[0]) * 60 + Number(parts[1]);
    };

    const ns = toMinutes(newStart);
    const ne = toMinutes(newEnd);

    for (const row of rows) {
      if (!row.start_time || !row.end_time) continue;
      const es = toMinutes(row.start_time);
      const ee = toMinutes(row.end_time);
      if (ns < ee && ne > es) {
        return true;
      }
    }
    return false;
  }

  async closeOrphanSessions(): Promise<void> {
    const database = await this.getDatabase();
    const now = new Date().toISOString();
    const today = now.split('T')[0];

    const openSessions = await database.getAllAsync<any>(
      "SELECT id, start_time FROM sessions WHERE state != 'CERRADA' AND state != 'NO_INICIADA' AND date < ?",
      [today ?? '']
    );

    for (const s of openSessions) {
      const endTime = s.start_time || '23:59';
      await database.runAsync(
        `UPDATE sessions
         SET state = 'CERRADA', integrity_type = 'AUTO', end_time = ?, updated_at = ?
         WHERE id = ?`,
        [endTime, now, s.id]
      );

      const eventId = Crypto.randomUUID();
      await database.runAsync(
        `INSERT INTO timeline_events (id, session_id, timestamp, description, status, sequence)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [eventId, s.id, now, 'Cierre automático por cambio de fecha', 'closed', 999]
      );
    }
  }

  async purgeZeroHourSessions(): Promise<void> {
    const database = await this.getDatabase();
    await database.runAsync(
      "DELETE FROM sessions WHERE total_hours <= 0 AND state = 'CERRADA'"
    );
  }

  // ── SUB-REPOSITORY METHODS ──────────────────────────────────

  async getVisits(sessionId: string): Promise<DestinationVisit[]> {
    const database = await this.getDatabase();
    const rows = await database.getAllAsync<any>(
      'SELECT * FROM destination_visits WHERE session_id = ? ORDER BY enter_time ASC',
      [sessionId]
    );
    return rows.map((r) => ({
      id: r.id,
      sessionId: r.session_id,
      destination: r.destination,
      alias: r.alias ?? undefined,
      enterTime: r.enter_time,
      exitTime: r.exit_time ?? undefined,
      lat: r.lat != null ? Number(r.lat) : undefined,
      lng: r.lng != null ? Number(r.lng) : undefined,
    }));
  }

  async getTransfers(sessionId: string): Promise<Transfer[]> {
    const database = await this.getDatabase();
    const rows = await database.getAllAsync<any>(
      'SELECT * FROM transfers WHERE session_id = ? ORDER BY start_time ASC',
      [sessionId]
    );
    return rows.map((r) => ({
      id: r.id,
      sessionId: r.session_id,
      originDestination: r.origin_destination,
      targetDestination: r.target_destination,
      destination: r.target_destination,
      startTime: r.start_time,
      endTime: r.end_time ?? undefined,
    }));
  }

  async getBreaks(sessionId: string): Promise<Break[]> {
    const database = await this.getDatabase();
    const rows = await database.getAllAsync<any>(
      'SELECT * FROM breaks WHERE session_id = ? ORDER BY start_time ASC',
      [sessionId]
    );
    return rows.map((r) => ({
      id: r.id,
      sessionId: r.session_id,
      startTime: r.start_time,
      endTime: r.end_time ?? undefined,
      durationMinutes: Number(r.duration_minutes ?? 0),
    }));
  }

  // ── PRIVATE HELPERS ───────────────────────────────────────

  private async _getTimelineEvents(
    database: SQLite.SQLiteDatabase,
    sessionId: string
  ): Promise<any[]> {
    return database.getAllAsync<any>(
      'SELECT * FROM timeline_events WHERE session_id = ? ORDER BY sequence ASC',
      [sessionId]
    );
  }

  private async _replaceTimelineEvents(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    events: TimelineEvent[]
  ): Promise<void> {
    await database.runAsync('DELETE FROM timeline_events WHERE session_id = ?', [sessionId]);

    const seenIds = new Set<string>();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    let sequence = 1;

    for (const event of events) {
      let eventId = event.id?.trim();

      if (!eventId || !uuidRegex.test(eventId)) {
        eventId = Crypto.randomUUID();
      }

      if (seenIds.has(eventId)) {
        continue;
      }
      seenIds.add(eventId);

      const metadata = event.metadata || null;

      await database.runAsync(
        `INSERT INTO timeline_events (id, session_id, timestamp, description, status, sequence, metadata)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [eventId, sessionId, event.timestamp, event.description, event.status, sequence, metadata]
      );

      sequence += 1;
    }
  }

  private async _replaceVisits(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    visits: DestinationVisit[]
  ): Promise<void> {
    await database.runAsync('DELETE FROM destination_visits WHERE session_id = ?', [sessionId]);

    for (const v of visits) {
      const visitId = v.id?.trim() || Crypto.randomUUID();
      await database.runAsync(
        `INSERT INTO destination_visits (id, session_id, destination, alias, enter_time, exit_time, lat, lng)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [visitId, sessionId, v.destination, v.alias || null, v.enterTime, v.exitTime || null, v.lat ?? null, v.lng ?? null]
      );
    }
  }

  private async _replaceTransfers(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    transfers: Transfer[]
  ): Promise<void> {
    await database.runAsync('DELETE FROM transfers WHERE session_id = ?', [sessionId]);

    for (const t of transfers) {
      const transferId = t.id?.trim() || Crypto.randomUUID();
      const origin = t.originDestination || (t as any).origin || '';
      const target = t.targetDestination || t.destination || '';

      await database.runAsync(
        `INSERT INTO transfers (id, session_id, origin_destination, target_destination, start_time, end_time)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [transferId, sessionId, origin, target, t.startTime, t.endTime || null]
      );
    }
  }

  private async _replaceBreaks(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    breaks: Break[]
  ): Promise<void> {
    await database.runAsync('DELETE FROM breaks WHERE session_id = ?', [sessionId]);

    for (const b of breaks) {
      const breakId = b.id?.trim() || Crypto.randomUUID();
      await database.runAsync(
        `INSERT INTO breaks (id, session_id, start_time, end_time, duration_minutes)
         VALUES (?, ?, ?, ?, ?)`,
        [breakId, sessionId, b.startTime, b.endTime || null, b.durationMinutes || 0]
      );
    }
  }

  private _mapRowToSession(row: any, events: any[]): Session {
    return {
      id: row.id,
      date: row.date,
      destination: row.destination,
      alias: row.alias ?? undefined,
      startTime: row.start_time,
      endTime: row.end_time ?? '',
      totalHours: Number(row.total_hours ?? 0),
      lunchDeductedMinutes: Number(row.lunch_deducted_minutes ?? 0),
      overtimeHours: Number(row.overtime_hours ?? 0),
      snapshotRate: Number(row.snapshot_rate ?? 0),
      totalEarnings: Number(row.total_earnings ?? 0),
      integrityType: row.integrity_type,
      notes: row.notes ?? undefined,
      state: row.state,
      visits: [],
      transfers: [],
      breaks: [],
      paidMinutes: Number(row.paid_minutes ?? 0),
      pauseMinutes: Number(row.pause_minutes ?? 0),
      transferMinutes: Number(row.transfer_minutes ?? 0),
      _lat: row._lat != null ? Number(row._lat) : undefined,
      _lng: row._lng != null ? Number(row._lng) : undefined,
      _deviceStatus: row._device_status ?? undefined,
      timelineEvents: events.map((event: any) => ({
        id: event.id,
        timestamp: event.timestamp,
        description: event.description,
        status: event.status,
        metadata: event.metadata ?? undefined,
      })),
    };
  }
}

export const sessionRepository = new SessionRepository();
export const databaseService = new DatabaseService();
