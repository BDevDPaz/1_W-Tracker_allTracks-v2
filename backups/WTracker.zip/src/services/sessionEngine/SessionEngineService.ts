// ============================================================
// SERVICE: SessionEngineService — Motor de sesiones de trabajo (CONSOLIDADO)
// Versión: 2.0.0 (Workday Engine V2.0 Canónico)
// Fuente: Blueprint Pantalla Hoy — Sección 3 | Matriz de Resiliencia
// Responsabilidad: Máquina de 7 estados, Geocercas dinámicas multi-destino, WAL
// ============================================================

import * as Crypto from 'expo-crypto';
import {
  Break,
  DestinationVisit,
  Session,
  SessionState,
  TimelineEvent,
  Transfer,
} from '../../types';
import { ISessionEngineService } from '../../types/contracts';
import { calculateEarnings } from '../../utils/formatters';
import { DatabaseService, sessionRepository } from '../database/DatabaseService';
import { geofenceService } from '../geofence/GeofenceService';
import { settingsService } from '../settings/SettingsService';

// ── ESTADO GLOBAL EN MEMORIA (SINGLETON) ──────────────────────
let _currentState: SessionState = 'NO_INICIADA';
let _activeSession: Session | null = null;

// Debounce foreground para evitar falsos positivos por GPS inestable (2 minutos)
const FOREGROUND_EXIT_DEBOUNCE_MS = 2 * 60 * 1000;

type SessionEngineListener = (state: SessionState, session: Session | null) => void;

// ── HELPERS DE TIEMPO Y FORMATO ──────────────────────────────
const getMinutesBetweenHHMM = (start: string, end: string): number => {
  if (!start || !end) return 0;
  const [h1, m1] = start.split(':').map(Number);
  const [h2, m2] = end.split(':').map(Number);
  if (h1 === undefined || m1 === undefined || h2 === undefined || m2 === undefined) return 0;
  let diff = h2 * 60 + m2 - (h1 * 60 + m1);
  if (diff < 0) diff += 1440; // Cruce de medianoche (24 horas)
  return diff;
};

const getCurrentTimeHHMM = (): string => {
  const now = new Date();
  return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
};

const parseBaseHours = (hhmm: string): number => {
  if (!hhmm) return 8;
  const parts = hhmm.split(':');
  const h = Number(parts[0] || 8);
  const m = Number(parts[1] || 0);
  return h + m / 60;
};

// ── IMPLEMENTACIÓN DEL SERVICIO ──────────────────────────────
export class SessionEngineService implements ISessionEngineService {
  private listeners = new Set<SessionEngineListener>();
  private _foregroundExitDetectedAt: number | null = null;

  // Acumuladores de métricas para sincronización con repositorio
  private _lastPaidMinutes = 0;
  private _lastPauseMinutes = 0;
  private _lastTransferMinutes = 0;

  reset(): void {
    _currentState = 'NO_INICIADA';
    _activeSession = null;
    this._foregroundExitDetectedAt = null;
    this._lastPaidMinutes = 0;
    this._lastPauseMinutes = 0;
    this._lastTransferMinutes = 0;
    this.emit();
  }

  // ── OBSERVER API ───────────────────────────────────────────

  subscribe(listener: SessionEngineListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit(): void {
    const sessionSnapshot: Session | null = _activeSession
      ? {
          ..._activeSession,
          timelineEvents: [..._activeSession.timelineEvents],
          visits: _activeSession.visits ? [..._activeSession.visits] : [],
          transfers: _activeSession.transfers ? [..._activeSession.transfers] : [],
          breaks: _activeSession.breaks ? [..._activeSession.breaks] : [],
        }
      : null;

    this.listeners.forEach((listener) => {
      try {
        listener(_currentState, sessionSnapshot);
      } catch (err) {
        console.error('[SessionEngine Listener Error]', err);
      }
    });
  }

  // ── READ API ───────────────────────────────────────────────

  getCurrentState(): SessionState {
    return _currentState;
  }

  getActiveSession(): Session | null {
    return _activeSession;
  }

  // ── SESSION LIFECYCLE V2 ───────────────────────────────────

  async startSession(payload: { destination: string; alias?: string }): Promise<Session> {
    if (_currentState !== 'NO_INICIADA') {
      throw new Error('Ya existe una sesión en curso');
    }

    const now = new Date();
    const dateStr = now.toISOString().split('T')[0]!;
    const timeStr = getCurrentTimeHHMM();
    const sessionId = this._generateUUID();
    const settings = settingsService.getSettings();

    // Intentar geocodificación del destino o fallback a ubicación actual
    const destinationLocation = await geofenceService.geocodeAddress(payload.destination);
    const currentLocation = destinationLocation ?? (await geofenceService.getCurrentLocation());

    const locationSource = destinationLocation
      ? 'GEOCODED_DESTINATION'
      : currentLocation
      ? 'CURRENT_LOCATION_FALLBACK'
      : 'UNKNOWN';

    _activeSession = {
      id: sessionId,
      date: dateStr,
      destination: payload.destination,
      alias: payload.alias,
      startTime: timeStr,
      endTime: '',
      totalHours: 0,
      lunchDeductedMinutes: 0,
      overtimeHours: 0,
      snapshotRate: await settingsService.getSnapshotRate(),
      totalEarnings: 0,
      integrityType: 'VALID',
      state: 'ESPERANDO',
      _lat: currentLocation?.lat,
      _lng: currentLocation?.lng,
      _deviceStatus: locationSource,
      timelineEvents: [
        {
          id: this._generateUUID(),
          timestamp: now.toISOString(),
          description: `Jornada configurada para ${payload.alias || payload.destination}`,
          status: 'pending',
        },
      ],
      visits: [],
      transfers: [],
      breaks: [],
    };

    _currentState = 'ESPERANDO';
    this._foregroundExitDetectedAt = null;

    await sessionRepository.create(_activeSession);

    if (currentLocation) {
      await geofenceService.register({
        latitude: currentLocation.lat,
        longitude: currentLocation.lng,
        radius: settings.geofenceRadius,
        identifier: sessionId,
      });
    }

    await this._writeWAL(sessionId, 'START_SESSION', {
      destination: payload.destination,
      alias: payload.alias,
      locationSource,
    });

    this.emit();
    return _activeSession;
  }

  async confirmArrival(): Promise<void> {
    if (!_activeSession || _currentState !== 'ESPERANDO') return;

    const nowStr = getCurrentTimeHHMM();
    _activeSession.startTime = nowStr;

    const visit: DestinationVisit = {
      id: this._generateUUID(),
      sessionId: _activeSession.id,
      destination: _activeSession.destination,
      alias: _activeSession.alias,
      enterTime: nowStr,
      lat: _activeSession._lat,
      lng: _activeSession._lng,
    };

    _activeSession.visits = [visit];
    _activeSession.timelineEvents.push({
      id: this._generateUUID(),
      timestamp: new Date().toISOString(),
      description: `Llegada confirmada a ${_activeSession.alias || _activeSession.destination}`,
      status: 'active',
    });

    _currentState = 'ACTIVA';
    _activeSession.state = 'ACTIVA';
    this._foregroundExitDetectedAt = null;
    this._updateMetrics();

    await sessionRepository.update(_activeSession.id, {
      startTime: _activeSession.startTime,
      state: 'ACTIVA',
      visits: _activeSession.visits,
      timelineEvents: _activeSession.timelineEvents,
    });

    await this._writeWAL(_activeSession.id, 'CONFIRM_ARRIVAL', { enterTime: nowStr });
    this.emit();
  }

  // ── TRANSICIONES DE JORNADA MULTI-DESTINO Y PAUSAS ─────────

  async startLunch(): Promise<void> {
    if (!_activeSession || (_currentState !== 'ACTIVA' && _currentState !== 'SALIDA')) return;

    const nowStr = getCurrentTimeHHMM();

    // 1. Cerrar la visita actual si está abierta
    const visits = _activeSession.visits || [];
    if (visits.length > 0) {
      const lastVisit = visits[visits.length - 1]!;
      if (!lastVisit.exitTime) {
        lastVisit.exitTime = nowStr;
      }
    }

    const newBreak: Break = {
      id: this._generateUUID(),
      sessionId: _activeSession.id,
      startTime: nowStr,
      durationMinutes: 0,
    };

    _activeSession.breaks = [...(_activeSession.breaks || []), newBreak];
    _activeSession.timelineEvents.push({
      id: this._generateUUID(),
      timestamp: new Date().toISOString(),
      description: 'Almuerzo / Pausa iniciada',
      status: 'warning',
    });

    _currentState = 'PAUSADA';
    _activeSession.state = 'PAUSADA';
    this._updateMetrics();

    await sessionRepository.update(_activeSession.id, {
      state: 'PAUSADA',
      visits: _activeSession.visits,
      breaks: _activeSession.breaks,
      timelineEvents: _activeSession.timelineEvents,
    });

    await this._writeWAL(_activeSession.id, 'START_LUNCH', { startTime: nowStr });
    this.emit();
  }

  async endLunch(): Promise<void> {
    if (!_activeSession || _currentState !== 'PAUSADA') return;

    const nowStr = getCurrentTimeHHMM();

    // 1. Cerrar la pausa abierta
    const breaks = _activeSession.breaks || [];
    if (breaks.length > 0) {
      const activeBreak = breaks[breaks.length - 1]!;
      if (!activeBreak.endTime) {
        activeBreak.endTime = nowStr;
        activeBreak.durationMinutes = getMinutesBetweenHHMM(activeBreak.startTime, nowStr);
      }
    }

    // 2. Iniciar nueva visita en el mismo destino
    const newVisit: DestinationVisit = {
      id: this._generateUUID(),
      sessionId: _activeSession.id,
      destination: _activeSession.destination,
      alias: _activeSession.alias,
      enterTime: nowStr,
      lat: _activeSession._lat,
      lng: _activeSession._lng,
    };

    _activeSession.visits = [...(_activeSession.visits || []), newVisit];
    _activeSession.timelineEvents.push({
      id: this._generateUUID(),
      timestamp: new Date().toISOString(),
      description: 'Fin de almuerzo: reanudación de trabajo',
      status: 'active',
    });

    _currentState = 'ACTIVA';
    _activeSession.state = 'ACTIVA';
    this._updateMetrics();

    await sessionRepository.update(_activeSession.id, {
      state: 'ACTIVA',
      visits: _activeSession.visits,
      breaks: _activeSession.breaks,
      timelineEvents: _activeSession.timelineEvents,
    });

    await this._writeWAL(_activeSession.id, 'END_LUNCH', { endTime: nowStr });
    this.emit();
  }

  async startTransfer(destination: string, alias?: string): Promise<void> {
    if (
      !_activeSession ||
      (_currentState !== 'ACTIVA' && _currentState !== 'SALIDA' && _currentState !== 'PAUSADA')
    )
      return;

    const nowStr = getCurrentTimeHHMM();

    // 1. Cerrar visita o pausa abierta
    if (_currentState === 'PAUSADA') {
      const breaks = _activeSession.breaks || [];
      if (breaks.length > 0) {
        const activeBreak = breaks[breaks.length - 1]!;
        if (!activeBreak.endTime) {
          activeBreak.endTime = nowStr;
          activeBreak.durationMinutes = getMinutesBetweenHHMM(activeBreak.startTime, nowStr);
        }
      }
    } else {
      const visits = _activeSession.visits || [];
      if (visits.length > 0) {
        const lastVisit = visits[visits.length - 1]!;
        if (!lastVisit.exitTime) {
          lastVisit.exitTime = nowStr;
        }
      }
    }

    // 2. Registrar el traslado
    const newTransfer: Transfer = {
      id: this._generateUUID(),
      sessionId: _activeSession.id,
      originDestination: _activeSession.destination,
      targetDestination: destination,
      startTime: nowStr,
    };

    _activeSession.transfers = [...(_activeSession.transfers || []), newTransfer];
    _activeSession.timelineEvents.push({
      id: this._generateUUID(),
      timestamp: new Date().toISOString(),
      description: `Iniciando traslado hacia: ${alias || destination}`,
      status: 'pending',
    });

    const sessionId = _activeSession.id;
    _activeSession.destination = destination;
    _activeSession.alias = alias;

    _currentState = 'TRASLADO';
    _activeSession.state = 'TRASLADO';
    this._updateMetrics();

    await sessionRepository.update(sessionId, {
      state: 'TRASLADO',
      destination: _activeSession.destination,
      alias: _activeSession.alias ?? undefined,
      visits: _activeSession.visits,
      breaks: _activeSession.breaks,
      transfers: _activeSession.transfers,
      timelineEvents: _activeSession.timelineEvents,
    });

    // 3. Reemplazo dinámico de geocerca para el nuevo destino
    const coords = await geofenceService.geocodeAddress(destination);
    if (coords) {
      _activeSession._lat = coords.lat;
      _activeSession._lng = coords.lng;
      await sessionRepository.update(sessionId, { _lat: coords.lat, _lng: coords.lng });

      await geofenceService.replaceGeofence(sessionId, {
        latitude: coords.lat,
        longitude: coords.lng,
        radius: settingsService.getSettings().geofenceRadius,
        identifier: sessionId,
      });
    }

    await this._writeWAL(sessionId, 'START_TRANSFER', { target: destination, startTime: nowStr });
    this.emit();
  }

  async completeTransfer(): Promise<void> {
    if (!_activeSession || _currentState !== 'TRASLADO') return;

    const nowStr = getCurrentTimeHHMM();

    // 1. Cerrar el traslado abierto
    const transfers = _activeSession.transfers || [];
    if (transfers.length > 0) {
      const activeTransfer = transfers[transfers.length - 1]!;
      if (!activeTransfer.endTime) {
        activeTransfer.endTime = nowStr;
      }
    }

    // 2. Registrar llegada al nuevo destino
    const newVisit: DestinationVisit = {
      id: this._generateUUID(),
      sessionId: _activeSession.id,
      destination: _activeSession.destination,
      alias: _activeSession.alias,
      enterTime: nowStr,
      lat: _activeSession._lat,
      lng: _activeSession._lng,
    };

    _activeSession.visits = [...(_activeSession.visits || []), newVisit];
    _activeSession.timelineEvents.push({
      id: this._generateUUID(),
      timestamp: new Date().toISOString(),
      description: `Llegada a nuevo destino: ${_activeSession.alias || _activeSession.destination}`,
      status: 'active',
    });

    _currentState = 'ACTIVA';
    _activeSession.state = 'ACTIVA';
    this._updateMetrics();

    await sessionRepository.update(_activeSession.id, {
      state: 'ACTIVA',
      visits: _activeSession.visits,
      transfers: _activeSession.transfers,
      timelineEvents: _activeSession.timelineEvents,
    });

    await this._writeWAL(_activeSession.id, 'COMPLETE_TRANSFER', { enterTime: nowStr });
    this.emit();
  }

  async finishWorkDay(lunchMinutes: number): Promise<Session> {
    if (!_activeSession || _currentState === 'CERRADA' || _currentState === 'NO_INICIADA') {
      throw new Error('No hay sesión activa para finalizar');
    }

    const nowStr = getCurrentTimeHHMM();
    _activeSession.endTime = nowStr;

    // 1. Cerrar cualquier visita, traslado o break abierto
    const visits = _activeSession.visits || [];
    if (visits.length > 0) {
      const lastVisit = visits[visits.length - 1]!;
      if (!lastVisit.exitTime) lastVisit.exitTime = nowStr;
    }

    const transfers = _activeSession.transfers || [];
    if (transfers.length > 0) {
      const activeTransfer = transfers[transfers.length - 1]!;
      if (!activeTransfer.endTime) activeTransfer.endTime = nowStr;
    }

    const breaks = _activeSession.breaks || [];
    if (breaks.length > 0) {
      const activeBreak = breaks[breaks.length - 1]!;
      if (!activeBreak.endTime) {
        activeBreak.endTime = nowStr;
        activeBreak.durationMinutes = getMinutesBetweenHHMM(activeBreak.startTime, nowStr);
      }
    }

    _activeSession.lunchDeductedMinutes = lunchMinutes;
    _activeSession.timelineEvents.push({
      id: this._generateUUID(),
      timestamp: new Date().toISOString(),
      description: `Jornada finalizada. Almuerzo descontado: ${lunchMinutes} min`,
      status: 'closed',
    });

    _currentState = 'CERRADA';
    _activeSession.state = 'CERRADA';
    this._updateMetrics();

    await geofenceService.unregister(_activeSession.id);

    const updatedSession = await sessionRepository.update(_activeSession.id, {
      endTime: _activeSession.endTime,
      state: 'CERRADA',
      lunchDeductedMinutes: _activeSession.lunchDeductedMinutes,
      totalHours: _activeSession.totalHours,
      overtimeHours: _activeSession.overtimeHours,
      totalEarnings: _activeSession.totalEarnings,
      visits: _activeSession.visits,
      transfers: _activeSession.transfers,
      breaks: _activeSession.breaks,
      timelineEvents: _activeSession.timelineEvents,
      paidMinutes: this._lastPaidMinutes,
      pauseMinutes: this._lastPauseMinutes,
      transferMinutes: this._lastTransferMinutes,
    });

    await this._writeWAL(_activeSession.id, 'FINISH_WORKDAY', { endTime: nowStr, lunchMinutes });

    const resultSession = { ...updatedSession };
    _currentState = 'NO_INICIADA';
    _activeSession = null;
    this._foregroundExitDetectedAt = null;

    this.emit();
    return resultSession;
  }

  // Métodos de compatibilidad de API
  async closeSession(lunchMinutes: number): Promise<Session> {
    return this.finishWorkDay(lunchMinutes);
  }

  async confirmExit(): Promise<Session> {
    return this.finishWorkDay(0);
  }

  async cancelSession(): Promise<void> {
    if (!_activeSession) return;

    const sessionId = _activeSession.id;
    await geofenceService.unregister(sessionId);
    await sessionRepository.delete(sessionId);
    await this._writeWAL(sessionId, 'SESSION_CANCELLED', {});

    _currentState = 'NO_INICIADA';
    _activeSession = null;
    this._foregroundExitDetectedAt = null;

    this.emit();
  }

  async addNote(note: string): Promise<void> {
    if (!_activeSession) return;

    _activeSession.notes = note;
    await sessionRepository.update(_activeSession.id, { notes: note });
    await this._writeWAL(_activeSession.id, 'NOTE_ADDED', { note });
    this.emit();
  }

  // ── GEOFENCE EVENT HANDLERS ────────────────────────────────

  async onGeofenceEnter(): Promise<void> {
    if (_currentState === 'ESPERANDO') {
      await this.confirmArrival();
    } else if (_currentState === 'TRASLADO') {
      await this.completeTransfer();
    }
  }

  async onGeofenceExit(): Promise<void> {
    if (_currentState !== 'ACTIVA') return;

    _currentState = 'SALIDA';
    if (_activeSession) {
      _activeSession.state = 'SALIDA';
      _activeSession.timelineEvents.push({
        id: this._generateUUID(),
        timestamp: new Date().toISOString(),
        description: 'Salida del área de trabajo detectada',
        status: 'warning',
      });

      await sessionRepository.update(_activeSession.id, {
        state: 'SALIDA',
        timelineEvents: _activeSession.timelineEvents,
      });

      await this._writeWAL(_activeSession.id, 'GEOFENCE_EXIT', {});
    }
    this.emit();
  }

  async validateForegroundExit(): Promise<void> {
    if (
      !_activeSession ||
      _currentState !== 'ACTIVA' ||
      _activeSession._lat == null ||
      _activeSession._lng == null
    ) {
      this._foregroundExitDetectedAt = null;
      return;
    }

    const settings = settingsService.getSettings();
    const radius = settings.geofenceRadius || 100;

    const result = await geofenceService.validateExitByCurrentLocation({
      center: { lat: _activeSession._lat, lng: _activeSession._lng },
      radiusMeters: radius,
    });

    if (result && result.isOutside) {
      if (this._foregroundExitDetectedAt === null) {
        this._foregroundExitDetectedAt = Date.now();
      } else {
        const elapsed = Date.now() - this._foregroundExitDetectedAt;
        if (elapsed >= FOREGROUND_EXIT_DEBOUNCE_MS) {
          this._foregroundExitDetectedAt = null;
          await this.onGeofenceExit();
        }
      }
    } else {
      this._foregroundExitDetectedAt = null;
    }
  }

  resumeFromExit(): void {
    if (_currentState !== 'SALIDA') return;

    _currentState = 'ACTIVA';
    if (_activeSession) {
      _activeSession.state = 'ACTIVA';
      _activeSession.timelineEvents.push({
        id: this._generateUUID(),
        timestamp: new Date().toISOString(),
        description: 'Trabajo reanudado (confirmación de usuario)',
        status: 'active',
      });

      void sessionRepository.update(_activeSession.id, {
        state: 'ACTIVA',
        timelineEvents: _activeSession.timelineEvents,
      });

      void this._writeWAL(_activeSession.id, 'RESUME_FROM_EXIT', {});
    }
    this.emit();
  }

  async handleMidnightCrossing(): Promise<void> {
    if (!_activeSession || _currentState === 'CERRADA' || _currentState === 'NO_INICIADA') return;

    await this._writeWAL(_activeSession.id, 'MIDNIGHT_PARTITION', {
      timestamp: new Date().toISOString(),
    });
  }

  // ── RESILIENCE & WAL REHYDRATION ────────────────────────────

  async rehydrateFromWAL(): Promise<'OK' | 'RECOVERED' | 'CONFLICT'> {
    try {
      const allSessions = await sessionRepository.getAll();
      const activeSessions = allSessions.filter(
        (s: any) => s.state !== 'CERRADA' && s.state !== 'NO_INICIADA'
      );

      if (activeSessions.length === 0) {
        _currentState = 'NO_INICIADA';
        _activeSession = null;
        this._foregroundExitDetectedAt = null;
        this.emit();
        return 'OK';
      }

      let conflictDetected = false;

      // Si existen múltiples sesiones activas por cierre forzado del OS, se cierran las antiguas
      if (activeSessions.length > 1) {
        conflictDetected = true;
        const staleSessions = activeSessions.slice(1);

        for (const stale of staleSessions) {
          await sessionRepository.update(stale.id, {
            endTime: stale.endTime || getCurrentTimeHHMM(),
            state: 'CERRADA',
            integrityType: 'CONFLICT',
            notes: stale.notes
              ? `${stale.notes}\nCerrada automáticamente por conflicto WAL.`
              : 'Cerrada automáticamente por conflicto WAL.',
          });

          await this._writeWAL(stale.id, 'AUTO_CLOSED_WAL_CONFLICT', {
            recoveredAt: new Date().toISOString(),
          });
        }
      }

      const recoveredSession = activeSessions[0]!;
      _activeSession = recoveredSession;
      _currentState = recoveredSession.state;
      this._foregroundExitDetectedAt = null;

      if (recoveredSession._lat != null && recoveredSession._lng != null) {
        await geofenceService.register({
          latitude: recoveredSession._lat,
          longitude: recoveredSession._lng,
          radius: settingsService.getSettings().geofenceRadius,
          identifier: recoveredSession.id,
        });
      }

      await this._writeWAL(recoveredSession.id, 'SESSION_RECOVERED_FROM_WAL', {
        state: _currentState,
      });

      this.emit();
      return conflictDetected ? 'CONFLICT' : 'RECOVERED';
    } catch (error) {
      console.error('[WAL Rehydration Error]', error);
      return 'OK';
    }
  }

  detectTimeDrift(currentTimestamp: number, previousTimestamp: number): boolean {
    if (currentTimestamp < previousTimestamp) {
      if (_activeSession) {
        _activeSession.integrityType = 'CONFLICT';
        void sessionRepository.update(_activeSession.id, { integrityType: 'CONFLICT' });
        void this._writeWAL(_activeSession.id, 'TIME_DRIFT_DETECTED', {
          currentTimestamp,
          previousTimestamp,
        });
      }
      this.emit();
      return true;
    }
    return false;
  }

  // ── PRIVATE HELPERS ────────────────────────────────────────

  private _generateUUID(): string {
    try {
      return Crypto.randomUUID();
    } catch (_) {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      });
    }
  }

  private async _writeWAL(sessionId: string, eventType: string, payload: object): Promise<void> {
    try {
      const db = DatabaseService.getDb();
      const id = this._generateUUID();
      const now = new Date().toISOString();

      await db.runAsync(
        `INSERT INTO wal_log (id, session_id, event_type, payload, created_at, synced)
         VALUES (?, ?, ?, ?, ?, 0)`,
        [id, sessionId, eventType, JSON.stringify(payload), now]
      );
    } catch (error) {
      console.warn('[WAL Write Failed]', error);
    }
  }

  private _updateMetrics(): void {
    if (!_activeSession) return;

    const currentTime = getCurrentTimeHHMM();

    // 1. Minutos productivos en visitas
    let productiveMinutes = 0;
    const visits = _activeSession.visits || [];
    for (const v of visits) {
      const end = v.exitTime || currentTime;
      productiveMinutes += getMinutesBetweenHHMM(v.enterTime, end);
    }

    // 2. Minutos en traslados
    let transferMinutes = 0;
    const transfers = _activeSession.transfers || [];
    for (const t of transfers) {
      const end = t.endTime || currentTime;
      transferMinutes += getMinutesBetweenHHMM(t.startTime, end);
    }

    // 3. Minutos en descansos / almuerzo activo
    let breakMinutes = 0;
    const breaks = _activeSession.breaks || [];
    for (const b of breaks) {
      const end = b.endTime || currentTime;
      breakMinutes += getMinutesBetweenHHMM(b.startTime, end);
    }

    const settings = settingsService.getSettings();
    const paidTransfersEnabled = settings.paidTransfers !== false;

    // Horas remuneradas (Visitas + Traslados remunerados - Almuerzo descontado)
    const totalPaidMinutesRaw = productiveMinutes + (paidTransfersEnabled ? transferMinutes : 0);
    const paidMinutesFinal = Math.max(0, totalPaidMinutesRaw - _activeSession.lunchDeductedMinutes);

    const totalHours = Number((paidMinutesFinal / 60).toFixed(2));

    // Guardar acumuladores para persistencia en SQLite
    this._lastPaidMinutes = paidMinutesFinal;
    this._lastPauseMinutes = breakMinutes + _activeSession.lunchDeductedMinutes;
    this._lastTransferMinutes = transferMinutes;

    const baseWorkHours = parseBaseHours(settings.baseWorkHour || '08:00');
    const overtimeHours = Number(Math.max(0, totalHours - baseWorkHours).toFixed(2));
    const rate = _activeSession.snapshotRate || settings.hourlyRate || 20;
    const overtimeMultiplier = settings.overtimeMultiplier || 1.5;

    _activeSession.totalHours = totalHours;
    _activeSession.overtimeHours = overtimeHours;
    _activeSession.totalEarnings = calculateEarnings(
      totalHours,
      rate,
      overtimeHours,
      overtimeMultiplier
    );
  }
}

export const sessionEngine = new SessionEngineService();
