// ============================================================
// SERVICE: GeofenceService — Monitoreo de geocerca nativa (CONSOLIDADO V2.1)
// Stack: expo-location + expo-task-manager Background
// ============================================================

import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import {
  Coordinates,
  ExitValidationResult,
  GeofenceConfig,
  GeofenceEvent,
  IGeofenceService,
} from '../../types/contracts';

// Nombre del task alineado con el Bloque 1 para consistencia
const GEOFENCE_TASK_NAME = 'WTRACKER_BACKGROUND_GEOFENCE_TASK';
const EXIT_DEBOUNCE_MS = 2 * 60 * 1000;

let globalGeofenceServiceInstance: GeofenceService | null = null;

// ── DEFINICIÓN DE TAREA EN SEGUNDO PLANO (OS BACKGROUND TASK) ──────
try {
  if (!TaskManager.isTaskDefined(GEOFENCE_TASK_NAME)) {
    TaskManager.defineTask(
      GEOFENCE_TASK_NAME,
      async ({ data, error }: { data: any; error: any }) => {
        if (error) {
          console.error('[Background Geofence Task Error]', error);
          return;
        }

        if (!data) return;

        const { eventType, region } = data as {
          eventType: Location.GeofencingEventType;
          region: Location.LocationRegion;
        };
        const identifier = region?.identifier ?? '';

        try {
          // CORRECCIÓN CRÍTICA: Ruta corregida basándonos en el Bloque 1
          const { sessionEngine } = require('../sessionEngine/SessionEngineService');

          if (eventType === Location.GeofencingEventType.Enter) {
            console.log(`[Background Geofence] ENTER detectado en: ${identifier}`);
            if (sessionEngine && typeof sessionEngine.onGeofenceEnter === 'function') {
              await sessionEngine.onGeofenceEnter();
            }
            if (globalGeofenceServiceInstance) {
              globalGeofenceServiceInstance.emitEvent('ENTER', identifier);
            }
          } else if (eventType === Location.GeofencingEventType.Exit) {
            console.log(`[Background Geofence] EXIT detectado en: ${identifier}`);
            if (sessionEngine && typeof sessionEngine.onGeofenceExit === 'function') {
              await sessionEngine.onGeofenceExit();
            }
            if (globalGeofenceServiceInstance) {
              globalGeofenceServiceInstance.emitEvent('EXIT', identifier);
            }
          }
        } catch (err) {
          console.error('[Background Geofence Task Dispatch Error]', err);
        }
      }
    );
  }
} catch (e) {
  // Evita errores ("Task is already defined") causados por el Fast Refresh / Hot Reload en desarrollo
  console.warn('[Geofence Task] Precaución de Hot Reload controlada.');
}

// ── CLASE CORE GEOFENCE SERVICE ──────────────────────────────
export class GeofenceService implements IGeofenceService {
  private _callbacks: Array<(event: GeofenceEvent, id: string) => void> = [];
  private _exitDebounceTimer: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    globalGeofenceServiceInstance = this;
  }

  async register(config: GeofenceConfig): Promise<void> {
    if (config.radius < 10) {
      throw new Error('Radio mínimo de geocerca: 10 metros');
    }

    try {
      const isAvailable = await Location.isBackgroundLocationAvailableAsync();
      if (!isAvailable) {
        console.warn('[Geofence] Location background mode no está disponible en este dispositivo');
        return;
      }

      const permission = await Location.getBackgroundPermissionsAsync();
      if (permission.status !== 'granted') {
        const requested = await this.requestPermissions();
        if (!requested) {
          console.warn('[Geofence] Permisos background no concedidos.');
          return;
        }
      }

      const isTaskRunning = await Location.hasStartedGeofencingAsync(GEOFENCE_TASK_NAME);
      if (isTaskRunning) {
        await Location.stopGeofencingAsync(GEOFENCE_TASK_NAME);
      }

      await Location.startGeofencingAsync(GEOFENCE_TASK_NAME, [
        {
          identifier: config.identifier,
          latitude: config.latitude,
          longitude: config.longitude,
          radius: config.radius,
          notifyOnEnter: true,
          notifyOnExit: true,
        },
      ]);
      console.log(`[Geofence] Registrada con éxito: ${config.identifier} (${config.radius}m)`);
    } catch (error) {
      console.error('[Geofence Register Failed]', error);
      throw error;
    }
  }

  async unregister(identifier: string): Promise<void> {
    if (this._exitDebounceTimer) {
      clearTimeout(this._exitDebounceTimer);
      this._exitDebounceTimer = null;
    }

    try {
      const isTaskRunning = await TaskManager.isTaskRegisteredAsync(GEOFENCE_TASK_NAME);
      if (isTaskRunning) {
        await Location.stopGeofencingAsync(GEOFENCE_TASK_NAME);
        console.log(`[Geofence] Removida del OS: ${identifier}`);
      }
    } catch (error) {
      console.warn(`[Geofence Unregister Warning] No se pudo remover ${identifier}`, error);
    }
  }

  async replaceGeofence(config: GeofenceConfig): Promise<void>;
  async replaceGeofence(oldIdentifier: string, newConfig: GeofenceConfig): Promise<void>;
  async replaceGeofence(
    param1: string | GeofenceConfig,
    param2?: GeofenceConfig
  ): Promise<void> {
    console.log('[Geofence] Iniciando reemplazo dinámico...');
    let oldId: string;
    let newConfig: GeofenceConfig;

    if (typeof param1 === 'string' && param2) {
      oldId = param1;
      newConfig = param2;
    } else {
      newConfig = param1 as GeofenceConfig;
      oldId = newConfig.identifier;
    }

    try {
      await this.unregister(oldId);
      await this.register(newConfig);
    } catch (error) {
      console.error('[Geofence replaceGeofence Failed]', error);
      throw error;
    }
  }

  async registerNextDestination(address: string, sessionId?: string): Promise<Coordinates | null> {
    const coords = await this.geocodeAddress(address);
    if (coords && sessionId) {
      const radius = 100;
      await this.replaceGeofence(sessionId, {
        latitude: coords.lat,
        longitude: coords.lng,
        radius,
        identifier: sessionId,
      });
    }
    return coords;
  }

  onEvent(callback: (event: GeofenceEvent, id: string) => void): () => void {
    this._callbacks.push(callback);
    return () => {
      this._callbacks = this._callbacks.filter((cb) => cb !== callback);
    };
  }

  emitEvent(event: GeofenceEvent, identifier: string): void {
    if (event === 'ENTER') {
      if (this._exitDebounceTimer) {
        console.log('[Geofence] Salida cancelada: reingreso detectado dentro del periodo de gracia.');
        clearTimeout(this._exitDebounceTimer);
        this._exitDebounceTimer = null;
      }
      this._triggerCallbacks('ENTER', identifier);
    } else if (event === 'EXIT') {
      if (this._exitDebounceTimer) {
        clearTimeout(this._exitDebounceTimer);
      }
      this._exitDebounceTimer = setTimeout(() => {
        console.log('[Geofence] Salida confirmada tras debounce.');
        this._exitDebounceTimer = null;
        this._triggerCallbacks('EXIT', identifier);
      }, EXIT_DEBOUNCE_MS);
    }
  }

  private _triggerCallbacks(event: GeofenceEvent, identifier: string): void {
    this._callbacks.forEach((callback) => {
      try {
        callback(event, identifier);
      } catch (err) {
        console.error('[Geofence Callback Error]', err);
      }
    });
  }

  async getCurrentLocation(): Promise<Coordinates | null> {
    try {
      const foreground = await Location.getForegroundPermissionsAsync();
      if (foreground.status !== 'granted') return null;

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      return {
        lat: location.coords.latitude,
        lng: location.coords.longitude,
      };
    } catch (error) {
      console.warn('[Geofence] Error obteniendo ubicación actual', error);
      return null;
    }
  }

  async geocodeAddress(address: string): Promise<Coordinates | null> {
    const normalizedAddress = address.trim();
    if (normalizedAddress.length === 0) return null;

    try {
      const results = await Location.geocodeAsync(normalizedAddress);
      if (results && results.length > 0) {
        return {
          lat: results[0]!.latitude,
          lng: results[0]!.longitude,
        };
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  async validateExitByCurrentLocation(params: {
    center: Coordinates;
    radiusMeters: number;
  }): Promise<ExitValidationResult | null> {
    const currentLocation = await this.getCurrentLocation();
    if (!currentLocation) return null;

    const distance = this._calculateDistanceMeters(params.center, currentLocation);
    return {
      isOutside: distance > params.radiusMeters,
      distanceMeters: Math.round(distance),
      radiusMeters: params.radiusMeters,
    };
  }

  async getPermissionStatus(): Promise<'GRANTED' | 'DENIED' | 'NOT_DETERMINED'> {
    try {
      const bg = await Location.getBackgroundPermissionsAsync();
      if (bg.status === 'granted') return 'GRANTED';
      const fg = await Location.getForegroundPermissionsAsync();
      if (fg.status === 'granted') return 'GRANTED';
      return bg.status === 'denied' || fg.status === 'denied' ? 'DENIED' : 'NOT_DETERMINED';
    } catch (error) {
      return 'NOT_DETERMINED';
    }
  }

  async requestPermissions(): Promise<boolean> {
    try {
      const fg = await Location.requestForegroundPermissionsAsync();
      if (fg.status !== 'granted') return false;
      const bg = await Location.requestBackgroundPermissionsAsync();
      return bg.status === 'granted';
    } catch (error) {
      return false;
    }
  }

  private _calculateDistanceMeters(from: Coordinates, to: Coordinates): number {
    const earthRadiusMeters = 6371000;
    const dLat = this._toRadians(to.lat - from.lat);
    const dLng = this._toRadians(to.lng - from.lng);

    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this._toRadians(from.lat)) *
        Math.cos(this._toRadians(to.lat)) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return earthRadiusMeters * c;
  }

  private _toRadians(degree: number): number {
    return (degree * Math.PI) / 180;
  }
}

export const geofenceService = new GeofenceService();

