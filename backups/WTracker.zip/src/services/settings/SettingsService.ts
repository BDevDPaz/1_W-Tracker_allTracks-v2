// ============================================================
// SERVICE: SettingsService — Configuración del usuario (CONSOLIDADO)
// Versión: 2.0.0 (Workday Tracking Platform - Multi-destino)
// Fuente: Blueprint Pantalla Ajustes — Sección 2
//         Matriz de Resiliencia — Sección 5.1 (snapshot_rate)
// ============================================================

import { UserSettings } from '../../types';
import { ISettingsService } from '../../types/contracts';
import { DatabaseService } from '../database/DatabaseService';

const SETTINGS_ID = 'user_settings';

const DEFAULT_SETTINGS: UserSettings = {
  name: '',
  hourlyRate: 20,
  reportEmail: '',
  baseWorkHour: '06:00',
  overtimeMultiplier: 1.5,
  lunchDiscountMinutes: 30,
  geofenceRadius: 100,
  dailyReminder: true,
  workdayAlerts: true,
  reportReady: true,
  language: 'es',
  multiDestination: false,
  paidTransfers: true,
  destinationLimit: 5,
};

export class SettingsService implements ISettingsService {
  private _cached: UserSettings | null = null;

  /**
   * Carga la configuración desde SQLite.
   * Si no existe la fila canónica, inserta los valores por defecto.
   */
  async load(): Promise<UserSettings> {
    if (this._cached) {
      return this._cached;
    }

    try {
      const db = DatabaseService.getDb();
      const row = await db.getFirstAsync<any>(
        'SELECT * FROM settings WHERE id = ? LIMIT 1',
        [SETTINGS_ID]
      );

      if (!row) {
        await this._insertDefaults();
        this._cached = { ...DEFAULT_SETTINGS };
        return this._cached;
      }

      this._cached = this._mapFromDB(row);
      return this._cached;
    } catch (error) {
      console.warn(
        '[SettingsService Load Warning] Fallo al cargar configuración desde SQLite. Retornando valores por defecto.',
        error
      );
      return { ...DEFAULT_SETTINGS };
    }
  }

  /**
   * Devuelve la configuración actualmente cargada en memoria.
   * Si aún no se ha ejecutado load(), entrega un objeto por defecto seguro.
   */
  getSettings(): UserSettings {
    return this._cached ?? { ...DEFAULT_SETTINGS };
  }

  /**
   * Persiste la configuración en la base de datos SQLite.
   */
  async save(settings: UserSettings): Promise<void> {
    this._validate(settings);

    try {
      const db = DatabaseService.getDb();
      const now = new Date().toISOString();

      await db.runAsync(
        `INSERT INTO settings (
          id, name, hourly_rate, report_email, base_work_hour, overtime_multiplier,
          lunch_discount_minutes, geofence_radius, daily_reminder, workday_alerts,
          report_ready, language, multi_destination, paid_transfers, destination_limit, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          name = excluded.name,
          hourly_rate = excluded.hourly_rate,
          report_email = excluded.report_email,
          base_work_hour = excluded.base_work_hour,
          overtime_multiplier = excluded.overtime_multiplier,
          lunch_discount_minutes = excluded.lunch_discount_minutes,
          geofence_radius = excluded.geofence_radius,
          daily_reminder = excluded.daily_reminder,
          workday_alerts = excluded.workday_alerts,
          report_ready = excluded.report_ready,
          language = excluded.language,
          multi_destination = excluded.multi_destination,
          paid_transfers = excluded.paid_transfers,
          destination_limit = excluded.destination_limit,
          updated_at = excluded.updated_at`,
        [
          SETTINGS_ID,
          settings.name,
          settings.hourlyRate,
          settings.reportEmail,
          settings.baseWorkHour,
          settings.overtimeMultiplier,
          settings.lunchDiscountMinutes,
          settings.geofenceRadius,
          settings.dailyReminder ? 1 : 0,
          settings.workdayAlerts ? 1 : 0,
          settings.reportReady ? 1 : 0,
          settings.language,
          settings.multiDestination ? 1 : 0,
          settings.paidTransfers ? 1 : 0,
          settings.destinationLimit ?? 5,
          now,
        ]
      );

      this._cached = { ...settings };
    } catch (error) {
      console.error('[SettingsService Save Failed] Error guardando configuración:', error);
      throw error;
    }
  }

  /**
   * Devuelve la tarifa por hora registrada para snapshot de sesión.
   */
  async getSnapshotRate(): Promise<number> {
    const settings = await this.load();
    return settings.hourlyRate;
  }

  /**
   * Invalida la memoria caché local.
   */
  clearCache(): void {
    this._cached = null;
  }

  // ── HELPERS PRIVADOS ───────────────────────────────────────

  private async _insertDefaults(): Promise<void> {
    try {
      const db = DatabaseService.getDb();
      const now = new Date().toISOString();

      await db.runAsync(
        `INSERT OR REPLACE INTO settings (
          id, name, hourly_rate, report_email, base_work_hour, overtime_multiplier,
          lunch_discount_minutes, geofence_radius, daily_reminder, workday_alerts,
          report_ready, language, multi_destination, paid_transfers, destination_limit, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          SETTINGS_ID,
          DEFAULT_SETTINGS.name,
          DEFAULT_SETTINGS.hourlyRate,
          DEFAULT_SETTINGS.reportEmail,
          DEFAULT_SETTINGS.baseWorkHour,
          DEFAULT_SETTINGS.overtimeMultiplier,
          DEFAULT_SETTINGS.lunchDiscountMinutes,
          DEFAULT_SETTINGS.geofenceRadius,
          DEFAULT_SETTINGS.dailyReminder ? 1 : 0,
          DEFAULT_SETTINGS.workdayAlerts ? 1 : 0,
          DEFAULT_SETTINGS.reportReady ? 1 : 0,
          DEFAULT_SETTINGS.language,
          DEFAULT_SETTINGS.multiDestination ? 1 : 0,
          DEFAULT_SETTINGS.paidTransfers ? 1 : 0,
          DEFAULT_SETTINGS.destinationLimit ?? 5,
          now,
        ]
      );
    } catch (error) {
      console.error('[SettingsService _insertDefaults Failed]', error);
    }
  }

  private _validate(settings: UserSettings): void {
    if (!Number.isFinite(settings.hourlyRate) || settings.hourlyRate <= 0) {
      throw new Error('La tarifa por hora debe ser un número mayor a 0');
    }
    if (settings.reportEmail.trim().length > 0 && !this._isValidEmail(settings.reportEmail)) {
      throw new Error('El correo electrónico de reportes no posee un formato válido');
    }
    if (!this._isValidTime(settings.baseWorkHour)) {
      throw new Error('La jornada base debe estar expresada en formato HH:MM (ej. 08:00)');
    }
    if (!Number.isFinite(settings.overtimeMultiplier) || settings.overtimeMultiplier < 1) {
      throw new Error('El multiplicador de horas extra debe ser mayor o igual a 1.0');
    }
    if (!Number.isInteger(settings.lunchDiscountMinutes) || settings.lunchDiscountMinutes < 0) {
      throw new Error('El descuento de almuerzo debe ser un número entero mayor o igual a 0');
    }
    if (!Number.isInteger(settings.geofenceRadius) || settings.geofenceRadius < 10) {
      throw new Error('El radio de geocerca debe ser un entero de al menos 10 metros');
    }
    if (
      settings.destinationLimit !== undefined &&
      (!Number.isInteger(settings.destinationLimit) || settings.destinationLimit <= 0)
    ) {
      throw new Error('El límite diario de destinos debe ser un entero mayor a 0');
    }
  }

  private _isValidTime(value: string): boolean {
    const cleanValue = value.trim();
    if (!/^\d{2}:\d{2}$/.test(cleanValue)) return false;

    const parts = cleanValue.split(':');
    const hours = Number(parts[0]);
    const minutes = Number(parts[1]);

    return (
      Number.isInteger(hours) &&
      Number.isInteger(minutes) &&
      hours >= 0 &&
      hours <= 23 &&
      minutes >= 0 &&
      minutes <= 59
    );
  }

  private _isValidEmail(value: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
  }

  private _mapFromDB(row: Record<string, unknown>): UserSettings {
    return {
      name: String(row['name'] ?? ''),
      hourlyRate: Number(row['hourly_rate'] ?? 20),
      reportEmail: String(row['report_email'] ?? ''),
      baseWorkHour: String(row['base_work_hour'] ?? '06:00'),
      overtimeMultiplier: Number(row['overtime_multiplier'] ?? 1.5),
      lunchDiscountMinutes: Number(row['lunch_discount_minutes'] ?? 30),
      geofenceRadius: Number(row['geofence_radius'] ?? 100),
      dailyReminder: Number(row['daily_reminder']) === 1,
      workdayAlerts: Number(row['workday_alerts']) === 1,
      reportReady: Number(row['report_ready']) === 1,
      language: row['language'] === 'en' ? 'en' : 'es',
      multiDestination: Number(row['multi_destination'] ?? 0) === 1,
      paidTransfers: Number(row['paid_transfers'] ?? 1) === 1,
      destinationLimit: Number(row['destination_limit'] ?? 5),
    };
  }
}

export const settingsService = new SettingsService();
