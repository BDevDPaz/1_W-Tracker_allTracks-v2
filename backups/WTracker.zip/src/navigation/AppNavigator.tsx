// ============================================================
// NAVIGATION: AppNavigator — Enrutador principal Tab + Stack (CONSOLIDADO V2.0)
// Versión: 2.0.0 (Workday Tracking Design System)
// Fuente: Blueprint de Navegación — Sección 1 | Identidad V2
// Responsabilidad: Navegación raíz. Combina BottomTabs estáticos con Stack.
// REGLA: La Tab Bar es un ancla PASIVA. Sin sombras flotantes ni FABs anidados.
// ============================================================

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';

import { Icon } from '../components';
import { IconName } from '../components/atoms/Icon';
import { AjustesScreen, HistorialScreen, HoyScreen, ReportesScreen } from '../screens';
import { FONT, PALETTE, RADIUS, SPACING, TEXT } from '../theme';
import { RootStackParamList, RootTabParamList } from '../types';

const Tab = createBottomTabNavigator<RootTabParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

type TabRouteName = keyof RootTabParamList;

const TAB_ICONS: Record<TabRouteName, IconName> = {
  Hoy: 'navigation',
  Historial: 'history',
  Reportes: 'file-text',
  Ajustes: 'settings',
};

// ── BOTTOM TABS ─────────────────────────────────────────────

function MainTabNavigator() {
  return (
    <Tab.Navigator
      initialRouteName="Hoy"
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: true,
        tabBarActiveTintColor: PALETTE.mutedGold,
        tabBarInactiveTintColor: TEXT.muted,
        tabBarStyle: styles.tabBar,
        tabBarItemStyle: styles.tabItem,
        tabBarLabelStyle: styles.tabLabel,
        tabBarHideOnKeyboard: true, // Ocultar al abrir teclados
        tabBarIcon: ({ focused }) => {
          const iconName = TAB_ICONS[route.name as TabRouteName];

          return (
            <View style={[styles.iconContainer, focused && styles.iconContainerActive]}>
              <Icon
                name={iconName}
                size={focused ? 20 : 18}
                color={focused ? PALETTE.mutedGold : TEXT.muted}
                strokeWidth={focused ? 2.5 : 2}
              />
            </View>
          );
        },
      })}
    >
      <Tab.Screen
        name="Hoy"
        component={HoyScreen}
        options={{ tabBarLabel: 'HOY' }}
      />
      <Tab.Screen
        name="Historial"
        component={HistorialScreen}
        options={{ tabBarLabel: 'HISTORIAL' }}
      />
      <Tab.Screen
        name="Reportes"
        component={ReportesScreen}
        options={{ tabBarLabel: 'REPORTES' }}
      />
      <Tab.Screen
        name="Ajustes"
        component={AjustesScreen}
        options={{ tabBarLabel: 'AJUSTES' }}
      />
    </Tab.Navigator>
  );
}

// ── ROOT STACK ──────────────────────────────────────────────

export const AppNavigator: React.FC = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MainTabs" component={MainTabNavigator} />
      {/* Futuras pantallas que requieran sobreponerse al TabBar completo 
        (ej. Modales FullScreen, Vistas de Detalle profundo) van aquí.
      */}
    </Stack.Navigator>
  );
};

// ── ESTILOS ─────────────────────────────────────────────────

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: PALETTE.graphite, // Nivel 1: Superficie sólida y estable
    borderTopColor: PALETTE.steelLine,
    borderTopWidth: 1,
    height: Platform.OS === 'ios' ? 88 : 72,
    paddingTop: SPACING.xs,
    paddingBottom: Platform.OS === 'ios' ? SPACING.xl : SPACING.sm,
    // Ancla Pasiva: Sin elevación ni sombras
    elevation: 0,
    shadowOpacity: 0,
  },
  tabItem: {
    paddingVertical: SPACING.xxs,
  },
  tabLabel: {
    fontSize: 9,
    fontWeight: '700',
    fontFamily: 'Montserrat',
    letterSpacing: 0.5,
    marginTop: SPACING.xxs,
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: RADIUS.xs,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconContainerActive: {
    backgroundColor: 'rgba(197, 160, 89, 0.12)', // mutedGold con opacidad
  },
});
