// ============================================================
// W TRACKER — TIPOS GLOBALES Y CONTRATOS DE DOMINIO V2.2
// Ruta: src/types/index.ts
// Versión: 2.2.1
//
// Este módulo es una hoja de dependencias.
// No debe importar ni reexportar desde ./contracts.
// ============================================================

export type PillStatus = 'idle' | 'pending' | 'active' | 'warning' | 'error' | 'closed';

export type IntegrityType = 'VALID' | 'MANUAL' | 'AUTO' | 'CONFLICT';

export type SessionState = 'NO_INICIADA' | 'ESPERANDO' | 'TRASLADO' | 'ACTIVA' | 'PAUSADA' | 'SALIDA' | 'CERRADA';

export interface DestinationVisit { id: string; sessionId?: string; destination: string; alias?: string; enterTime: string; exitTime?: string; lat?: number; lng?: number; visits?: ReadonlyArray<DestinationVisit>; session_id?: string; name?: string; arrival_time?: string; departure_time?: string | null; }

export interface Transfer { id: string; sessionId?: string; originDestination: string; targetDestination: string; destination?: string; startTime: string; endTime?: string; isPaid?: boolean; session_id?: string; origin_destination?: string; target_destination?: string; start_time?: string; end_time?: string | null; is_paid?: 0 | 1; }

export interface Break { id: string; sessionId?: string; startTime: string; endTime?: string; durationMinutes: number; isPaid?: boolean; session_id?: string; start_time?: string; end_time?: string | null; duration_minutes?: number; is_paid?: 0 | 1; }

export interface TimelineEvent { id: string; timestamp: string; description: string; status: PillStatus; type?: SessionState; title?: string; metadata?: string; time?: string; }

export interface Session { id: string; date: string; destination: string; alias?: string; startTime: string; endTime: string; state: SessionState; integrityType: IntegrityType; totalHours: number; lunchDeductedMinutes: number; overtimeHours: number; snapshotRate: number; totalEarnings: number; notes?: string; timelineEvents: TimelineEvent[]; visits?: DestinationVisit[]; transfers?: Transfer[]; breaks?: Break[]; paidMinutes?: number; pauseMinutes?: number; transferMinutes?: number; destinationCount?: number; _lat?: number; _lng?: number; _radius?: number; _deviceStatus?: string; start_time?: string; end_time?: string | null; total_hours?: number; lunch_deducted_minutes?: number; overtime_hours?: number; snapshot_rate?: number; total_earnings?: number; integrity_type?: IntegrityType; paid_minutes?: number; pause_minutes?: number; transfer_minutes?: number; destination_count?: number; }

export interface WorkDay extends Session { visits: DestinationVisit[]; transfers: Transfer[]; breaks: Break[]; }

export interface UserSettings { name: string; hourlyRate: number; reportEmail: string; baseWorkHour: string; overtimeMultiplier: number; lunchDiscountMinutes: number; geofenceRadius: number; dailyReminder: boolean; workdayAlerts: boolean; reportReady: boolean; language: 'es' | 'en'; paidTransfers: boolean; multiDestination: boolean; destinationLimit: number; hasCompletedOnboarding: boolean; }

export interface WeeklySummary { periodLabel: string; totalHours: number; totalEarnings: number; sessionCount: number; manualAdjustments: number; overtimeHours: number; baseEarnings: number; overtimeEarnings: number; baseRate: number; overtimeMultiplier: number; }

export interface PDFReport { periodLabel: string; weekStart: string; weekEnd: string; generatedAt: string; summary: WeeklySummary; sessions: Session[]; }

export interface DailySetupPayload { destination: string; alias?: string; }

export interface LunchModalPayload { minutes: 0 | 30 | 45 | 60; }

export type RootStackParamList = { Onboarding: undefined; MainTabs: undefined; };

export type RootTabParamList = { Hoy: undefined; Historial: undefined; Reportes: undefined; Ajustes: undefined; };

export type SystemHealthStatus = 'OK' | 'WARNING' | 'ERROR';

export interface SystemHealth { locationPermission: SystemHealthStatus; backgroundLocation: SystemHealthStatus; geofenceActive: SystemHealthStatus; notificationsReady: SystemHealthStatus; storageIntegrity: SystemHealthStatus; lastValidationMinutes?: number; }