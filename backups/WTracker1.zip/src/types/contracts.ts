// ============================================================
// W TRACKER: CONTRATOS DE API Y SERVICIOS INTERNOS V2.2
// Versión: 2.2.0 (Workday Tracking Platform)
//
// Fuente:
//   - Contratos de API y servicios internos V2.0
//   - Rediseño del dominio y contratos de datos V2
//   - Matriz de resiliencia V2.1
//   - Arquitectura multi-destino
//   - Geofencing dinámico V2.2
//
// Responsabilidad:
//   - Modelos de persistencia SQLite
//   - Contratos de repositorios
//   - Motor de jornadas
//   - Geocercas nativas
//   - Configuración de usuario
//   - Generación de PDF
//   - Notificaciones internas
//   - Recuperación mediante WAL
// ============================================================

import type { Break, DestinationVisit, IntegrityType, PDFReport, PillStatus, Session, SessionState, SystemHealth, SystemHealthStatus, TimelineEvent, Transfer, UserSettings, WeeklySummary } from './index';

export type { Break, DestinationVisit, IntegrityType, PDFReport, PillStatus, Session, SessionState, SystemHealth, SystemHealthStatus, TimelineEvent, Transfer, UserSettings, WeeklySummary };

// ═══════════════════════════════════════════════════════════
// 1. DATABASE SCHEMA CONTRACTS
// SQLite Mirror V2.2
// ═══════════════════════════════════════════════════════════

/**
 * Registro plano de una sesión o jornada almacenada en SQLite.
 */
export interface DB_Session {
  id: string;
  date: string;

  destination: string;
  alias: string | null;

  start_time: string;
  end_time: string | null;

  total_hours: number;
  lunch_deducted_minutes: number;
  overtime_hours: number;

  snapshot_rate: number;
  total_earnings: number;

  integrity_type: IntegrityType;
  notes: string | null;
  state: SessionState;

  /**
   * Acumuladores de tiempo expresados en minutos.
   */
  paid_minutes: number;
  pause_minutes: number;
  transfer_minutes: number;

  destination_count: number;

  /**
   * Configuración de la geocerca inicial.
   */
  _lat: number | null;
  _lng: number | null;
  _radius: number | null;

  /**
   * Estado serializado o descripción del dispositivo
   * al registrar la jornada.
   */
  _device_status: string | null;

  /**
   * Marcas temporales ISO 8601 de auditoría.
   */
  created_at: string;
  updated_at: string;
}

/**
 * Registro relacional de una visita operativa.
 */
export interface DB_DestinationVisit {
  id: string;
  session_id: string;

  destination: string;
  alias: string | null;

  enter_time: string;
  exit_time: string | null;

  lat: number | null;
  lng: number | null;

  /**
   * Campo heredado del esquema inicial.
   *
   * @deprecated Utilizar `destination`.
   */
  name?: string;

  /**
   * Campo heredado del esquema inicial.
   *
   * @deprecated Utilizar `enter_time`.
   */
  arrival_time?: string;

  /**
   * Campo heredado del esquema inicial.
   *
   * @deprecated Utilizar `exit_time`.
   */
  departure_time?: string | null;
}

/**
 * Registro relacional de un traslado entre destinos.
 */
export interface DB_Transfer {
  id: string;
  session_id: string;

  origin_destination: string;
  target_destination: string;

  start_time: string;
  end_time: string | null;

  /**
   * SQLite representa los booleanos mediante 0 y 1.
   */
  is_paid: 0 | 1;
}

/**
 * Registro relacional de una pausa o almuerzo.
 */
export interface DB_Break {
  id: string;
  session_id: string;

  start_time: string;
  end_time: string | null;

  duration_minutes: number;

  /**
   * SQLite representa los booleanos mediante 0 y 1.
   */
  is_paid: 0 | 1;
}

/**
 * Hito perteneciente al timeline de una sesión.
 */
export interface DB_TimelineEvent {
  id: string;
  session_id: string;

  /**
   * Marca temporal ISO 8601 del evento.
   */
  timestamp: string;

  /**
   * Estado de sesión asociado al evento.
   */
  type: SessionState;

  title: string;
  description: string | null;

  status: string;
  sequence: number;

  /**
   * Metadatos serializados como JSON.
   *
   * Pueden contener coordenadas, origen del evento,
   * información del dispositivo u otros datos auxiliares.
   */
  metadata: string | null;

  /**
   * Campo temporal heredado.
   *
   * @deprecated Utilizar `timestamp`.
   */
  time?: string;
}

/**
 * Entrada del Write-Ahead Log utilizada para recuperar una
 * jornada después de un cierre forzado o una interrupción.
 */
export interface DB_WALEntry {
  id: string;
  session_id: string;

  event_type: string;

  /**
   * Contenido del evento serializado como JSON.
   */
  payload: string;

  created_at: string;
  synced: 0 | 1;
}

/**
 * Registro canónico de configuración almacenado en SQLite.
 */
export interface DB_Settings {
  id: string;

  name: string;
  hourly_rate: number;
  report_email: string;
  base_work_hour: string;

  overtime_multiplier: number;
  lunch_discount_minutes: number;
  geofence_radius: number;

  daily_reminder: 0 | 1;
  workday_alerts: 0 | 1;
  report_ready: 0 | 1;

  language: 'es' | 'en';

  /**
   * Gobernabilidad multi-destino.
   */
  multi_destination: 0 | 1;
  paid_transfers: 0 | 1;
  destination_limit: number;

  /**
   * Estado del onboarding.
   */
  has_completed_onboarding: 0 | 1;

  /**
   * Marca temporal ISO 8601 de auditoría.
   */
  updated_at: string;
}

// ═══════════════════════════════════════════════════════════
// 2. SESSION ENGINE CONTRACTS
// Workday Engine V2.2
// ═══════════════════════════════════════════════════════════

/**
 * Posición utilizada al iniciar una sesión.
 */
export interface SessionStartLocation {
  lat: number;
  lng: number;
  radius: number;
}

/**
 * Datos necesarios para iniciar una nueva jornada.
 */
export interface StartSessionPayload {
  destination: string;
  alias?: string;
  location?: SessionStartLocation;
}

/**
 * Parámetro de compatibilidad para consumidores V2.0 que
 * iniciaban una sesión proporcionando únicamente coordenadas.
 */
export type LegacySessionStartLocation = SessionStartLocation;

/**
 * Contrato principal del motor de jornadas.
 *
 * El motor representa la fuente de verdad para las transiciones
 * de estado de una sesión activa.
 */
export interface ISessionEngineService {
  // ── Estado actual ─────────────────────────────────────────

  getCurrentState(): SessionState;

  getActiveSession(): Session | null;

  // ── Inicio de jornada ─────────────────────────────────────

  /**
   * Firma canónica para iniciar una jornada.
   */
  startSession(
    payload: StartSessionPayload,
  ): Promise<Session>;

  /**
   * Firma de compatibilidad V2.0.
   *
   * Permite iniciar una jornada sin payload o proporcionando
   * únicamente una ubicación inicial.
   */
  startSession(
    location?: LegacySessionStartLocation,
  ): Promise<Session>;

  confirmArrival(): Promise<void>;

  // ── Pausas y almuerzo ────────────────────────────────────

  startLunch(): Promise<void>;

  endLunch(): Promise<void>;

  /**
   * Alias genérico para iniciar una pausa.
   */
  pauseSession(): Promise<void>;

  /**
   * Alias genérico para finalizar una pausa.
   */
  resumeSession(): Promise<void>;

  // ── Multi-destino ────────────────────────────────────────

  addDestination(
    destination: string,
    alias?: string,
  ): Promise<void>;

  closeCurrentDestination(): Promise<void>;

  // ── Traslados ────────────────────────────────────────────

  startTransfer(
    destination: string,
    alias?: string,
  ): Promise<void>;

  completeTransfer(): Promise<void>;

  /**
   * Alias de compatibilidad para completar un traslado.
   */
  endTransfer(): Promise<void>;

  // ── Cierre de jornada ────────────────────────────────────

  /**
   * Finaliza la jornada aplicando la deducción indicada.
   */
  finishWorkDay(
    lunchMinutes: number,
  ): Promise<Session>;

  /**
   * Firma canónica de compatibilidad para cierre con minutos
   * de almuerzo.
   */
  closeSession(
    lunchMinutes: number,
  ): Promise<Session>;

  /**
   * Firma de compatibilidad V2.0 para cierre mediante una
   * marca temporal ISO 8601 opcional.
   */
  closeSession(
    endTime?: string,
  ): Promise<Session>;

  confirmExit(): Promise<Session>;

  cancelSession(): Promise<void>;

  addNote(
    note: string,
  ): Promise<void>;

  // ── Geocercas y validación foreground ────────────────────

  onGeofenceEnter(): Promise<void>;

  onGeofenceExit(): Promise<void>;

  validateForegroundExit(): Promise<void>;

  resumeFromExit(): void;

  // ── Resiliencia y recuperación ───────────────────────────

  rehydrateFromWAL(): Promise<RehydrationResult>;

  detectTimeDrift(
    currentTimestamp: number,
    previousTimestamp: number,
  ): boolean;

  // ── Observadores ─────────────────────────────────────────

  /**
   * Registra un listener y devuelve una función idempotente
   * para cancelar la suscripción.
   */
  subscribe(
    listener: (
      state: SessionState,
      session: Session | null,
    ) => void,
  ): () => void;

  /**
   * Reinicia el motor.
   *
   * Se utiliza principalmente durante pruebas, desarrollo
   * o recuperación controlada.
   */
  reset?(): void;
}

/**
 * Alias de compatibilidad para consumidores que importaban
 * `ISessionEngine` desde versiones anteriores.
 */
export type ISessionEngine = ISessionEngineService;

// ═══════════════════════════════════════════════════════════
// 3. REPOSITORY CONTRACT
// ═══════════════════════════════════════════════════════════

/**
 * Contrato del repositorio de sesiones.
 *
 * El repositorio se encarga del mapeo entre registros SQLite
 * y modelos del dominio.
 */
export interface ISessionRepository {
  getAll(): Promise<Session[]>;

  getById(
    id: string,
  ): Promise<Session | null>;

  getByPeriod(
    startDate: string,
    endDate: string,
  ): Promise<Session[]>;

  /**
   * Devuelve la sesión activa persistida, si existe.
   */
  getActive(): Promise<Session | null>;

  /**
   * Persiste una sesión y devuelve el modelo resultante.
   *
   * Los consumidores que no necesiten el valor de retorno
   * pueden ignorarlo de forma segura.
   */
  create(
    session: Session,
  ): Promise<Session>;

  update(
    id: string,
    patch: Partial<Session>,
  ): Promise<Session>;

  delete(
    id: string,
  ): Promise<void>;

  getWeeklySummary(
    startDate: string,
    endDate: string,
  ): Promise<WeeklySummary>;

  // ── Relaciones V2.0 ──────────────────────────────────────

  getVisits(
    sessionId: string,
  ): Promise<DestinationVisit[]>;

  getTransfers(
    sessionId: string,
  ): Promise<Transfer[]>;

  getBreaks(
    sessionId: string,
  ): Promise<Break[]>;
}

// ═══════════════════════════════════════════════════════════
// 4. GEOFENCE CONTRACTS
// Dynamic Geofencing V2.2
// ═══════════════════════════════════════════════════════════

/**
 * Configuración utilizada para registrar una geocerca nativa.
 */
export interface GeofenceConfig {
  identifier: string;
  latitude: number;
  longitude: number;
  radius: number;
}

/**
 * Eventos nativos soportados por una geocerca.
 */
export type GeofenceEvent =
  | 'ENTER'
  | 'EXIT';

/**
 * Estado normalizado de permisos de ubicación.
 */
export type GeofencePermissionStatus =
  | 'GRANTED'
  | 'DENIED'
  | 'NOT_DETERMINED';

/**
 * Coordenadas geográficas utilizadas por el dominio.
 */
export interface Coordinates {
  lat: number;
  lng: number;
}

/**
 * Resultado de una validación manual de salida.
 */
export interface ExitValidationResult {
  isOutside: boolean;
  distanceMeters: number;
  radiusMeters: number;
}

/**
 * Listener utilizado para distribuir eventos de geocerca.
 */
export type GeofenceEventListener = (
  event: GeofenceEvent,
  identifier: string,
) => void | Promise<void>;

/**
 * Contrato de integración con los servicios de ubicación
 * y geocercas del sistema operativo.
 */
export interface IGeofenceService {
  /**
   * Registra o sustituye la geocerca nativa activa.
   */
  register(
    config: GeofenceConfig,
  ): Promise<void>;

  /**
   * Elimina las regiones asociadas a la tarea nativa.
   *
   * El identificador es opcional porque determinadas
   * implementaciones detienen la tarea completa.
   */
  unregister(
    identifier?: string,
  ): Promise<void>;

  /**
   * Reemplaza la geocerca activa utilizando el identificador
   * incluido en la nueva configuración.
   */
  replaceGeofence(
    config: GeofenceConfig,
  ): Promise<void>;

  /**
   * Reemplaza explícitamente una geocerca identificada.
   */
  replaceGeofence(
    oldIdentifier: string,
    newConfig: GeofenceConfig,
  ): Promise<void>;

  /**
   * Geocodifica y registra el siguiente destino.
   *
   * Cuando la implementación completa el registro sin devolver
   * coordenadas, puede resolver la promesa con `void`.
   */
  registerNextDestination(
    address: string,
    sessionId?: string,
  ): Promise<Coordinates | null | void>;

  /**
   * Registra un listener y devuelve su función de limpieza.
   */
  onEvent(
    callback: GeofenceEventListener,
  ): () => void;

  /**
   * Devuelve la posición actual cuando existe permiso suficiente.
   */
  getCurrentLocation(): Promise<Coordinates | null>;

  /**
   * Convierte una dirección en coordenadas.
   */
  geocodeAddress(
    address: string,
  ): Promise<Coordinates | null>;

  /**
   * Comprueba si la posición actual se encuentra fuera del radio.
   */
  validateExitByCurrentLocation(
    params: {
      center: Coordinates;
      radiusMeters: number;
    },
  ): Promise<ExitValidationResult | null>;

  /**
   * Devuelve el estado normalizado de los permisos.
   */
  getPermissionStatus(): Promise<GeofencePermissionStatus>;

  /**
   * Solicita permisos foreground y background.
   */
  requestPermissions(): Promise<boolean>;

  /**
   * Libera listeners y temporizadores en implementaciones que
   * mantienen recursos en memoria.
   *
   * No implica necesariamente eliminar la geocerca del sistema.
   */
  dispose?(): void;
}

// ═══════════════════════════════════════════════════════════
// 5. PDF SERVICE
// ═══════════════════════════════════════════════════════════

export interface IPDFService {
  /**
   * Genera el archivo PDF y devuelve su ruta local.
   */
  generate(
    report: PDFReport,
  ): Promise<string>;

  /**
   * Abre el diálogo nativo para compartir el archivo.
   */
  share(
    filePath: string,
  ): Promise<void>;

  /**
   * Inicia el envío del archivo por correo electrónico.
   */
  sendByEmail(
    filePath: string,
    to: string,
  ): Promise<void>;

  /**
   * Abre una vista previa del archivo.
   */
  preview(
    filePath: string,
  ): Promise<void>;
}

// ═══════════════════════════════════════════════════════════
// 6. SETTINGS SERVICE
// ═══════════════════════════════════════════════════════════

export interface ISettingsService {
  /**
   * Carga la configuración desde persistencia.
   */
  load(): Promise<UserSettings>;

  /**
   * Valida y persiste la configuración.
   */
  save(
    settings: UserSettings,
  ): Promise<void>;

  /**
   * Devuelve la configuración disponible en memoria.
   *
   * La implementación debe evitar exponer una referencia
   * mutable a su estado interno.
   */
  getSettings(): UserSettings;

  /**
   * Devuelve la tarifa aplicable al snapshot de una sesión.
   */
  getSnapshotRate(): Promise<number>;

  /**
   * Invalida la configuración almacenada en memoria.
   */
  clearCache(): void;
}

// ═══════════════════════════════════════════════════════════
// 7. TOAST NOTIFICATIONS
// ═══════════════════════════════════════════════════════════

export type ToastType =
  | 'success'
  | 'info'
  | 'warning'
  | 'error';

export interface ToastMessage {
  id: string;
  type: ToastType;
  text: string;
  durationMs?: number;
}

export interface IToastQueue {
  push(
    message: Omit<ToastMessage, 'id'>,
  ): void;

  clear(): void;
}

// ═══════════════════════════════════════════════════════════
// 8. SESSION FILTERS
// ═══════════════════════════════════════════════════════════

export type SessionFilter =
  | 'TODO'
  | 'SEMANA'
  | 'MES'
  | 'AJUSTADAS'
  | 'AUTO_CERRADAS'
  | 'PENDIENTES';

export const FILTER_LABELS: Readonly<
  Record<SessionFilter, string>
> = Object.freeze({
  TODO: 'Todas las jornadas',
  SEMANA: 'Esta semana',
  MES: 'Este mes',
  AJUSTADAS: 'Ajustes manuales',
  AUTO_CERRADAS: 'Cierres de sistema',
  PENDIENTES: 'Jornadas activas',
});

// ═══════════════════════════════════════════════════════════
// 9. RESILIENCE
// ═══════════════════════════════════════════════════════════

/**
 * Resultado del proceso de rehidratación.
 *
 * NONE:
 * No había información pendiente en el WAL.
 *
 * OK:
 * El WAL y la sesión persistida ya eran consistentes.
 *
 * RECOVERED:
 * La sesión pudo reconstruirse desde el WAL.
 *
 * CONFLICT:
 * Se detectó una inconsistencia que requiere resolución.
 */
export type RehydrationResult =
  | 'NONE'
  | 'OK'
  | 'RECOVERED'
  | 'CONFLICT';

// ═══════════════════════════════════════════════════════════
// 10. USER SETTINGS
// ═══════════════════════════════════════════════════════════

/**
 * Configuración de usuario utilizada por la capa de dominio.
 *
 * Esta interfaz se declara únicamente en este módulo y debe
 * reexportarse desde `types/index.ts`.
 */
