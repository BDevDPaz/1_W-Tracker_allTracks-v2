// ============================================================
// W TRACKER — UTILIDADES GLOBALES Y LÓGICA DE NEGOCIO (CONSOLIDADO)
// Versión: 2.0.0 (Workday Tracking Architecture)
// Fuente: Guía Técnica & Especificación Arquitectónica UI/UX
// Responsabilidad: Formateadores, Cálculos de Nómina, Mapeo UI y Microcopy
// ============================================================

import { PALETTE } from '../theme';
import { IntegrityType, PillStatus, SessionState } from '../types';

// ── 1. FORMATEADORES FINANCIEROS Y DE TIEMPO ────────────────

/**
 * Formatea montos monetarios en formato localizado (USD por defecto) con 2 decimales para precisión de nómina.
 * Ej: 150.5 -> "$150.50"
 */
export const formatCurrency = (amount: number, currency = 'USD'): string => {
  if (!Number.isFinite(amount)) return '$0.00';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

/**
 * Formatea horas decimales a representación de texto legible.
 * Ej: 8.5 -> "8.5 h"
 */
export const formatHours = (hours: number): string => {
  const safeHours = Number.isFinite(hours) ? hours : 0;
  return `${safeHours.toFixed(1)} h`;
};

/**
 * Formatea una fecha ISO (YYYY-MM-DD) a string legible localizado en español.
 * Ej: "2026-08-10" -> "ago. 10, 2026"
 */
export const formatDate = (isoDate: string): string => {
  if (!isoDate) return '';
  const date = new Date(isoDate.includes('T') ? isoDate : `${isoDate}T00:00:00`);
  if (isNaN(date.getTime())) return isoDate;

  return date.toLocaleDateString('es-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
};

/**
 * Convierte un string de hora en formato 24 horas (HH:MM) a 12 horas con AM/PM.
 * Ej: "14:30" -> "2:30 PM"
 */
export const formatTime12 = (hhmm: string): string => {
  if (!hhmm || hhmm === '--:--') return '--:--';

  const [hStr, mStr] = hhmm.split(':');
  if (!hStr || !mStr) return '--:--';

  const h = parseInt(hStr, 10);
  if (!Number.isFinite(h)) return '--:--';

  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;

  return `${h12}:${mStr.padStart(2, '0')} ${ampm}`;
};

/**
 * Formatea un rango de horas de inicio y fin en formato legible de 12 horas.
 * Soporta sesiones en curso cuando el parámetro 'end' es nulo o vacío.
 * Ej: ("08:00", "16:30") -> "8:00 AM — 4:30 PM"
 * Ej: ("08:00", "") -> "8:00 AM — En curso"
 */
export const formatTimeRange = (start: string, end?: string | null): string => {
  const startFormatted = formatTime12(start);
  const endFormatted = end ? formatTime12(end) : 'En curso';
  return `${startFormatted} — ${endFormatted}`;
};

// ── 2. MAPEO OPERATIVO (MÁQUINA DE ESTADOS → UI) ─────────────

export interface SessionStateUIMap {
  pillLabel: string;
  destinationSubtext: string;
  ctaPrimary: string;
  ctaSecondary?: string;
  showTimer: boolean;
}

/**
 * Mapea la máquina de 7 estados de SessionState a los textos y botones de la tarjeta Hero.
 */
export const getSessionStateUI = (state: SessionState): SessionStateUIMap => {
  const map: Record<SessionState, SessionStateUIMap> = {
    NO_INICIADA: {
      pillLabel: 'No iniciada',
      destinationSubtext: 'Configura tu jornada',
      ctaPrimary: 'Iniciar jornada',
      showTimer: false,
    },
    ESPERANDO: {
      pillLabel: 'Esperando llegada',
      destinationSubtext: 'Esperando llegada física al destino',
      ctaPrimary: 'Confirmar llegada',
      ctaSecondary: 'Cancelar jornada',
      showTimer: false,
    },
    TRASLADO: {
      pillLabel: 'En traslado',
      destinationSubtext: 'Transitando hacia nuevo destino',
      ctaPrimary: 'Confirmar llegada',
      ctaSecondary: 'Ajustar destino',
      showTimer: true,
    },
    ACTIVA: {
      pillLabel: 'Jornada activa',
      destinationSubtext: 'Trabajando en destino validado',
      ctaPrimary: 'Finalizar jornada',
      ctaSecondary: 'Iniciar almuerzo',
      showTimer: true,
    },
    PAUSADA: {
      pillLabel: 'En almuerzo',
      destinationSubtext: 'Tiempo de almuerzo / pausa',
      ctaPrimary: 'Finalizar almuerzo',
      ctaSecondary: 'Agregar nota',
      showTimer: true,
    },
    SALIDA: {
      pillLabel: 'Salida detectada',
      destinationSubtext: 'Fuera del radio de la geocerca',
      ctaPrimary: 'Confirmar salida',
      ctaSecondary: 'Seguir trabajando',
      showTimer: true,
    },
    CERRADA: {
      pillLabel: 'Jornada cerrada',
      destinationSubtext: 'Auditoría completada',
      ctaPrimary: 'Revisar jornada',
      ctaSecondary: 'Ver historial',
      showTimer: false,
    },
  };

  return map[state] ?? map.NO_INICIADA;
};

/**
 * Mapea el estado del Pill a la paleta semántica del tema.
 */
export const getStatusColor = (status: PillStatus): string => {
  const map: Record<PillStatus, string> = {
    idle: PALETTE.slateBlue,
    pending: PALETTE.royalBlue ?? PALETTE.amberWarning,
    active: PALETTE.successGreen,
    warning: PALETTE.amberWarning,
    error: PALETTE.deepRed,
    closed: PALETTE.slateBlue,
  };

  return map[status] ?? PALETTE.slateBlue;
};

/**
 * Mapea el estado técnico de PillStatus a etiquetas en lenguaje amigable.
 */
export const getStatusLabel = (status: PillStatus): string => {
  const map: Record<PillStatus, string> = {
    idle: 'No iniciada',
    pending: 'Esperando llegada',
    active: 'Jornada activa',
    warning: 'Salida detectada',
    error: 'Se requiere revisión',
    closed: 'Jornada cerrada',
  };

  return map[status] ?? 'Desconocido';
};

// ── 3. AUDITORÍA E INTEGRIDAD FORENSE ─────────────────────────

export interface IntegrityBadgeConfig {
  label: string;
  borderColor: string;
  textColor: string;
  icon: string;
}

/**
 * Retorna la configuración de estilo e icono para Badges de Integridad Forense.
 */
export const getIntegrityConfig = (type: IntegrityType): IntegrityBadgeConfig => {
  const map: Record<IntegrityType, IntegrityBadgeConfig> = {
    VALID: {
      label: 'Validada',
      borderColor: PALETTE.successGreen,
      textColor: PALETTE.successGreen,
      icon: 'shield-check',
    },
    MANUAL: {
      label: 'Ajuste manual',
      borderColor: '#9CA3AF',
      textColor: '#9CA3AF',
      icon: 'pencil',
    },
    AUTO: {
      label: 'Auto cierre',
      borderColor: PALETTE.slateBlue,
      textColor: PALETTE.slateBlue,
      icon: 'clock',
    },
    CONFLICT: {
      label: 'Revisar',
      borderColor: PALETTE.amberWarning,
      textColor: PALETTE.amberWarning,
      icon: 'alert-triangle',
    },
  };

  return map[type] ?? map.VALID;
};

// ── 4. LÓGICA DE NÓMINA Y MANEJO DE TIEMPOS ──────────────────

/**
 * Evalúa si un rango horario propuesto colisiona con uno existente.
 */
export const isTimeOverlapping = (
  newStart: string,
  newEnd: string,
  existingStart: string,
  existingEnd: string
): boolean => {
  const toMinutes = (t: string): number => {
    if (!t) return 0;
    const parts = t.split(':');
    const h = parseInt(parts[0] ?? '0', 10);
    const m = parseInt(parts[1] ?? '0', 10);

    if (!Number.isFinite(h) || !Number.isFinite(m)) {
      return 0;
    }

    return h * 60 + m;
  };

  const ns = toMinutes(newStart);
  const ne = toMinutes(newEnd);
  const es = toMinutes(existingStart);
  const ee = toMinutes(existingEnd);

  return ns < ee && ne > es;
};

/**
 * Calcula la nómina diaria basándose en horas base, tarifa por hora y horas extra.
 * Fórmula: (Hours - Overtime) * Rate + (Overtime * Rate * OvertimeMultiplier)
 */
export const calculateEarnings = (
  hours: number,
  rate: number,
  overtimeHours: number,
  overtimeMultiplier: number
): number => {
  const validHours = Math.max(0, Number.isFinite(hours) ? hours : 0);
  const validRate = Math.max(0, Number.isFinite(rate) ? rate : 0);
  const validOtHours = Math.max(0, Number.isFinite(overtimeHours) ? overtimeHours : 0);
  const validOtMultiplier = Number.isFinite(overtimeMultiplier) ? overtimeMultiplier : 1.5;

  const baseHours = Math.max(0, validHours - validOtHours);
  const basePay = baseHours * validRate;
  const overtimePay = validOtHours * validRate * validOtMultiplier;

  return Math.round((basePay + overtimePay) * 100) / 100;
};

/**
 * Calcula la diferencia exacta en minutos entre dos cadenas de hora HH:MM.
 * Soporta turnos nocturnos / cruce de medianoche.
 */
export const getMinutesBetweenHHMM = (start: string, end: string): number => {
  if (!start || !end) return 0;
  const [h1, m1] = start.split(':').map(Number);
  const [h2, m2] = end.split(':').map(Number);

  if (h1 === undefined || m1 === undefined || h2 === undefined || m2 === undefined) return 0;
  if (!Number.isFinite(h1) || !Number.isFinite(m1) || !Number.isFinite(h2) || !Number.isFinite(m2)) return 0;

  let diff = (h2 * 60 + m2) - (h1 * 60 + m1);
  if (diff < 0) diff += 1440; // Ajuste por cambio de día (24h)

  return diff;
};

/**
 * Calcula la diferencia absoluta en minutos entre dos cadenas ISO 8601.
 */
export const minutesBetween = (isoA: string, isoB: string): number => {
  const a = new Date(isoA).getTime();
  const b = new Date(isoB).getTime();

  if (isNaN(a) || isNaN(b)) return 0;

  const removeMs = (t: number) => Math.floor(t / 60000) * 60000;
  return Math.round(Math.abs(removeMs(b) - removeMs(a)) / 60000);
};

// ── 5. CALCULADORES DE FECHAS Y RANGOS DE SEMANA ─────────────

/**
 * Retorna la fecha ISO (YYYY-MM-DD) correspondiente al lunes de la semana solicitada.
 */
export const getWeekStart = (offsetWeeks = 0): string => {
  const today = new Date();
  const day = today.getDay(); // 0 = Domingo, 1 = Lunes
  const diff = (day === 0 ? -6 : 1 - day) + offsetWeeks * 7;
  const monday = new Date(today);

  monday.setDate(today.getDate() + diff);

  return monday.toISOString().split('T')[0]!;
};

/**
 * Formatea un rango de semana de lunes a domingo para UI.
 * Ej: "2026-08-10" -> "ago. 10 — ago. 16"
 */
export const formatWeekRange = (weekStart: string): string => {
  const start = new Date(weekStart.includes('T') ? weekStart : `${weekStart}T00:00:00`);
  if (isNaN(start.getTime())) return weekStart;

  const end = new Date(start);
  end.setDate(start.getDate() + 6);

  const fmt = (d: Date) =>
    d.toLocaleDateString('es-US', {
      month: 'short',
      day: 'numeric',
    });

  return `${fmt(start)} — ${fmt(end)}`;
};

/**
 * Comprueba si una fecha en formato ISO (YYYY-MM-DD) es el día actual.
 */
export const isToday = (isoDate: string): boolean => {
  if (!isoDate) return false;
  const todayIso = new Date().toISOString().split('T')[0];
  return isoDate === todayIso;
};

// ── 6. DICCIONARIOS DE COMUNICACIÓN Y MICROCOPY ─────────────

/**
 * Microcopy aprobado para abstraer términos técnicos internos hacia lenguaje comprensible.
 */
export const MICROCOPY: Record<string, string> = {
  'Geofence activada': 'Zona activa',
  'Geocerca activada': 'Zona activa',
  'Pending arrival': 'Esperando llegada',
  'Background task ejecutada': 'Monitoreo protegido',
  'Registro editado manualmente': 'Ajuste manual aplicado',
  'Error crítico / Mutex failed': 'Se requiere revisión antes de continuar',
  'WAL entry written': 'Sesión protegida',
  'Scheduler triggered': 'Monitoreo protegido',
  'Clock drift': 'Inconsistencia horaria detectada',
  'Geofence breach': 'Salida detectada',
};

/**
 * Mensajes de estado para operaciones de carga asíncronas.
 */
export const LOADING_COPY: Record<string, string> = {
  closeSession: 'Cerrando jornada...',
  generateReport: 'Generando reporte PDF...',
  syncLocation: 'Sincronizando ubicación...',
  saveSettings: 'Guardando configuración...',
  exportPDF: 'Generando reporte PDF...',
  restoreSession: 'Restaurando sesión...',
};
