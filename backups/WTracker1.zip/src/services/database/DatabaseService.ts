// ============================================================
// SERVICE: DatabaseService — Motor SQLite consolidado V2.2
// Ruta: src/services/database/DatabaseService.ts
// Versión: 2.2.0 (Workday Tracking Platform)
//
// Responsabilidades:
// - Inicialización única y segura de SQLite.
// - Journal mode WAL y claves foráneas.
// - Migraciones idempotentes por inspección del esquema.
// - Persistencia de sesiones y relaciones multi-destino.
// - Timeline de auditoría.
// - Write-Ahead Log de aplicación.
// - Configuración y key-value store.
// - Cálculo de resúmenes semanales.
// - Recuperación y cierre de sesiones huérfanas.
// ============================================================

import * as Crypto from 'expo-crypto';
import * as SQLite from 'expo-sqlite';

import type {
  Break,
  DB_Break,
  DB_DestinationVisit,
  DB_Session,
  DB_TimelineEvent,
  DB_Transfer,
  DestinationVisit,
  ISessionRepository,
  PillStatus,
  Session,
  SessionState,
  TimelineEvent,
  Transfer,
  WeeklySummary,
} from '../../types/contracts';

// Mantener este nombre estable para no crear otra base de datos
// distinta en instalaciones existentes.
const DATABASE_NAME = 'wtracker.db';
const SETTINGS_ID = 'user_settings';

type SQLiteValue = string | number | null;

interface SQLiteTableColumn {
  cid: number;
  name: string;
  type: string;
  notnull: number;
  dflt_value: unknown;
  pk: number;
}

interface SQLiteUserVersion {
  user_version: number;
}

interface WeeklySessionRow {
  total_hours: number | null;
  total_earnings: number | null;
  overtime_hours: number | null;
  snapshot_rate: number | null;
  integrity_type: string | null;
}

interface SettingsRateRow {
  hourly_rate: number | null;
  overtime_multiplier: number | null;
}

interface SnapshotRateRow {
  snapshot_rate: number | null;
}

interface OverlapRow {
  start_time: string;
  end_time: string | null;
}

interface OrphanSessionRow {
  id: string;
  date: string;
  start_time: string;
}

interface CountRow {
  count: number;
}

interface WALRow {
  id: string;
  session_id: string;
  event_type: string;
  payload: string;
  created_at: string;
  synced: 0 | 1;
}

interface KeyValueRow {
  value: string;
}

const DB_SCHEMA = `
  CREATE TABLE IF NOT EXISTS sessions (
    id                       TEXT PRIMARY KEY NOT NULL,
    date                     TEXT NOT NULL,
    destination              TEXT NOT NULL DEFAULT '',
    alias                    TEXT,
    start_time               TEXT NOT NULL,
    end_time                 TEXT,
    total_hours              REAL NOT NULL DEFAULT 0,
    lunch_deducted_minutes   INTEGER NOT NULL DEFAULT 0,
    overtime_hours           REAL NOT NULL DEFAULT 0,
    snapshot_rate            REAL NOT NULL DEFAULT 20,
    total_earnings           REAL NOT NULL DEFAULT 0,
    integrity_type TEXT NOT NULL DEFAULT 'VALID',
    notes                    TEXT,
    state                    TEXT NOT NULL DEFAULT 'NO_INICIADA',
    paid_minutes             INTEGER NOT NULL DEFAULT 0,
    pause_minutes            INTEGER NOT NULL DEFAULT 0,
    transfer_minutes         INTEGER NOT NULL DEFAULT 0,
    destination_count        INTEGER NOT NULL DEFAULT 1,
    _lat                     REAL,
    _lng                     REAL,
    _radius                  REAL,
    _device_status           TEXT,
    created_at               TEXT NOT NULL,
    updated_at               TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS destination_visits (
    id                       TEXT PRIMARY KEY NOT NULL,
    session_id               TEXT NOT NULL,
    destination              TEXT NOT NULL,
    alias                    TEXT,
    enter_time               TEXT NOT NULL,
    exit_time                TEXT,
    lat                      REAL,
    lng                      REAL,
    FOREIGN KEY (session_id)
      REFERENCES sessions(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS transfers (
    id                       TEXT PRIMARY KEY NOT NULL,
    session_id               TEXT NOT NULL,
    origin_destination       TEXT NOT NULL,
    target_destination       TEXT NOT NULL,
    start_time               TEXT NOT NULL,
    end_time                 TEXT,
    is_paid                  INTEGER NOT NULL DEFAULT 1
                               CHECK (is_paid IN (0, 1)),
    FOREIGN KEY (session_id)
      REFERENCES sessions(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS breaks (
    id                       TEXT PRIMARY KEY NOT NULL,
    session_id               TEXT NOT NULL,
    start_time               TEXT NOT NULL,
    end_time                 TEXT,
    duration_minutes         INTEGER NOT NULL DEFAULT 0,
    is_paid                  INTEGER NOT NULL DEFAULT 0
                               CHECK (is_paid IN (0, 1)),
    FOREIGN KEY (session_id)
      REFERENCES sessions(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS timeline_events (
    id                       TEXT PRIMARY KEY NOT NULL,
    session_id               TEXT NOT NULL,
    timestamp                TEXT NOT NULL,
    type                     TEXT,
    title                    TEXT NOT NULL DEFAULT '',
    description              TEXT NOT NULL DEFAULT '',
    status                   TEXT NOT NULL DEFAULT 'idle',
    sequence                 INTEGER NOT NULL DEFAULT 0,
    metadata                 TEXT,
    FOREIGN KEY (session_id)
      REFERENCES sessions(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS wal_log (
    id                       TEXT PRIMARY KEY NOT NULL,
    session_id               TEXT NOT NULL,
    event_type               TEXT NOT NULL,
    payload                  TEXT NOT NULL,
    created_at               TEXT NOT NULL,
    synced                   INTEGER NOT NULL DEFAULT 0
                               CHECK (synced IN (0, 1))
  );

  CREATE TABLE IF NOT EXISTS settings (
    id                       TEXT PRIMARY KEY NOT NULL
                               DEFAULT '${SETTINGS_ID}',
    name                     TEXT NOT NULL DEFAULT '',
    hourly_rate              REAL NOT NULL DEFAULT 20,
    report_email             TEXT NOT NULL DEFAULT '',
    base_work_hour           TEXT NOT NULL DEFAULT '06:00',
    overtime_multiplier      REAL NOT NULL DEFAULT 1.5,
    lunch_discount_minutes   INTEGER NOT NULL DEFAULT 30,
    geofence_radius          INTEGER NOT NULL DEFAULT 100,
    daily_reminder           INTEGER NOT NULL DEFAULT 1
                               CHECK (daily_reminder IN (0, 1)),
    workday_alerts           INTEGER NOT NULL DEFAULT 1
                               CHECK (workday_alerts IN (0, 1)),
    report_ready             INTEGER NOT NULL DEFAULT 1
                               CHECK (report_ready IN (0, 1)),
    language                 TEXT NOT NULL DEFAULT 'es'
                               CHECK (language IN ('es', 'en')),
    multi_destination        INTEGER NOT NULL DEFAULT 0
                               CHECK (multi_destination IN (0, 1)),
    paid_transfers           INTEGER NOT NULL DEFAULT 1
                               CHECK (paid_transfers IN (0, 1)),
    destination_limit        INTEGER NOT NULL DEFAULT 5,
    has_completed_onboarding INTEGER NOT NULL DEFAULT 0
                               CHECK (has_completed_onboarding IN (0, 1)),
    updated_at               TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS key_value_store (
    key                      TEXT PRIMARY KEY NOT NULL,
    value                    TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_sessions_date
    ON sessions(date);

  CREATE INDEX IF NOT EXISTS idx_sessions_state
    ON sessions(state);

  CREATE INDEX IF NOT EXISTS idx_sessions_active
    ON sessions(end_time, state);

  CREATE INDEX IF NOT EXISTS idx_visits_session
    ON destination_visits(session_id, enter_time);

  CREATE INDEX IF NOT EXISTS idx_transfers_session
    ON transfers(session_id, start_time);

  CREATE INDEX IF NOT EXISTS idx_breaks_session
    ON breaks(session_id, start_time);

  CREATE INDEX IF NOT EXISTS idx_timeline_session
    ON timeline_events(session_id, sequence);

  CREATE INDEX IF NOT EXISTS idx_wal_session
    ON wal_log(session_id, created_at);

  CREATE INDEX IF NOT EXISTS idx_wal_synced
    ON wal_log(synced, created_at);
`;

// ── MIGRATION HELPERS ───────────────────────────────────────

function assertSafeIdentifier(identifier: string): void {
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(identifier)) {
    throw new Error(`Identificador SQLite inválido: ${identifier}`);
  }
}

async function columnExists(
  database: SQLite.SQLiteDatabase,
  tableName: string,
  columnName: string
): Promise<boolean> {
  assertSafeIdentifier(tableName);
  assertSafeIdentifier(columnName);

  const columns = await database.getAllAsync<SQLiteTableColumn>(
    `PRAGMA table_info("${tableName}")`
  );

  return columns.some((column) => column.name === columnName);
}

async function addColumnIfMissing(
  database: SQLite.SQLiteDatabase,
  tableName: string,
  columnName: string,
  definition: string
): Promise<void> {
  assertSafeIdentifier(tableName);
  assertSafeIdentifier(columnName);

  const exists = await columnExists(
    database,
    tableName,
    columnName
  );

  if (exists) {
    return;
  }

  await database.execAsync(
    `ALTER TABLE "${tableName}"
     ADD COLUMN "${columnName}" ${definition};`
  );
}

async function runMigrations(
  database: SQLite.SQLiteDatabase
): Promise<void> {
  // ── Sessions ─────────────────────────────────────────────

  await addColumnIfMissing(
    database,
    'sessions',
    'paid_minutes',
    'INTEGER NOT NULL DEFAULT 0'
  );

  await addColumnIfMissing(
    database,
    'sessions',
    'pause_minutes',
    'INTEGER NOT NULL DEFAULT 0'
  );

  await addColumnIfMissing(
    database,
    'sessions',
    'transfer_minutes',
    'INTEGER NOT NULL DEFAULT 0'
  );

  await addColumnIfMissing(
    database,
    'sessions',
    'destination_count',
    'INTEGER NOT NULL DEFAULT 1'
  );

  await addColumnIfMissing(
    database,
    'sessions',
    '_lat',
    'REAL'
  );

  await addColumnIfMissing(
    database,
    'sessions',
    '_lng',
    'REAL'
  );

  await addColumnIfMissing(
    database,
    'sessions',
    '_radius',
    'REAL'
  );

  await addColumnIfMissing(
    database,
    'sessions',
    '_device_status',
    'TEXT'
  );

  // ── Timeline ─────────────────────────────────────────────

  await addColumnIfMissing(
    database,
    'timeline_events',
    'type',
    'TEXT'
  );

  await addColumnIfMissing(
    database,
    'timeline_events',
    'title',
    "TEXT NOT NULL DEFAULT ''"
  );

  await addColumnIfMissing(
    database,
    'timeline_events',
    'description',
    "TEXT NOT NULL DEFAULT ''"
  );

  await addColumnIfMissing(
    database,
    'timeline_events',
    'status',
    "TEXT NOT NULL DEFAULT 'idle'"
  );

  await addColumnIfMissing(
    database,
    'timeline_events',
    'sequence',
    'INTEGER NOT NULL DEFAULT 0'
  );

  await addColumnIfMissing(
    database,
    'timeline_events',
    'metadata',
    'TEXT'
  );

  // ── Transfers and breaks ─────────────────────────────────

  await addColumnIfMissing(
    database,
    'transfers',
    'is_paid',
    'INTEGER NOT NULL DEFAULT 1'
  );

  await addColumnIfMissing(
    database,
    'breaks',
    'duration_minutes',
    'INTEGER NOT NULL DEFAULT 0'
  );

  await addColumnIfMissing(
    database,
    'breaks',
    'is_paid',
    'INTEGER NOT NULL DEFAULT 0'
  );

  // ── Settings ─────────────────────────────────────────────

  await addColumnIfMissing(
    database,
    'settings',
    'multi_destination',
    'INTEGER NOT NULL DEFAULT 0'
  );

  await addColumnIfMissing(
    database,
    'settings',
    'paid_transfers',
    'INTEGER NOT NULL DEFAULT 1'
  );

  await addColumnIfMissing(
    database,
    'settings',
    'destination_limit',
    'INTEGER NOT NULL DEFAULT 5'
  );

  await addColumnIfMissing(
    database,
    'settings',
    'has_completed_onboarding',
    'INTEGER NOT NULL DEFAULT 0'
  );

  await database.execAsync(`
    UPDATE sessions
    SET destination_count = 1
    WHERE destination_count IS NULL OR destination_count < 1;

    UPDATE sessions
    SET integrity_type = 'VALID'
    WHERE integrity_type IS NULL OR TRIM(integrity_type) = '';

    UPDATE timeline_events
    SET description = ''
    WHERE description IS NULL;

    UPDATE timeline_events
    SET status = 'idle'
    WHERE status IS NULL OR TRIM(status) = '';

    UPDATE timeline_events
    SET sequence = rowid
    WHERE sequence IS NULL OR sequence <= 0;

    UPDATE settings
    SET
      multi_destination = COALESCE(multi_destination, 0),
      paid_transfers = COALESCE(paid_transfers, 1),
      destination_limit = COALESCE(destination_limit, 5),
      has_completed_onboarding =
        COALESCE(has_completed_onboarding, 0);
  `);

  await database.runAsync(
    `INSERT OR IGNORE INTO settings (
      id,
      name,
      hourly_rate,
      report_email,
      base_work_hour,
      overtime_multiplier,
      lunch_discount_minutes,
      geofence_radius,
      daily_reminder,
      workday_alerts,
      report_ready,
      language,
      multi_destination,
      paid_transfers,
      destination_limit,
      has_completed_onboarding,
      updated_at
    ) VALUES (?, '', 20, '', '06:00', 1.5, 30, 100, 1, 1, 1,
              'es', 0, 1, 5, 0, ?)`,
    SETTINGS_ID,
    new Date().toISOString()
  );

  await database.execAsync(`
    CREATE INDEX IF NOT EXISTS idx_sessions_date
      ON sessions(date);

    CREATE INDEX IF NOT EXISTS idx_sessions_state
      ON sessions(state);

    CREATE INDEX IF NOT EXISTS idx_sessions_active
      ON sessions(end_time, state);

    CREATE INDEX IF NOT EXISTS idx_visits_session
      ON destination_visits(session_id, enter_time);

    CREATE INDEX IF NOT EXISTS idx_transfers_session
      ON transfers(session_id, start_time);

    CREATE INDEX IF NOT EXISTS idx_breaks_session
      ON breaks(session_id, start_time);

    CREATE INDEX IF NOT EXISTS idx_timeline_session
      ON timeline_events(session_id, sequence);

    CREATE INDEX IF NOT EXISTS idx_wal_session
      ON wal_log(session_id, created_at);

    CREATE INDEX IF NOT EXISTS idx_wal_synced
      ON wal_log(synced, created_at);

    PRAGMA user_version = 2;
  `);
}

// ── DATABASE SERVICE ────────────────────────────────────────

export class DatabaseService {
  private static database: SQLite.SQLiteDatabase | null = null;

  private static initializationPromise: Promise<void> | null = null;

  static async initialize(): Promise<void> {
    if (this.database) {
      return;
    }

    if (this.initializationPromise) {
      return this.initializationPromise;
    }

    this.initializationPromise = this.initializeInternal();

    try {
      await this.initializationPromise;
    } finally {
      this.initializationPromise = null;
    }
  }

  private static async initializeInternal(): Promise<void> {
    let openedDatabase: SQLite.SQLiteDatabase | null = null;

    try {
      openedDatabase = await SQLite.openDatabaseAsync(DATABASE_NAME);

      await openedDatabase.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        PRAGMA busy_timeout = 5000;
      `);

      await openedDatabase.execAsync(DB_SCHEMA);
      await runMigrations(openedDatabase);

      const foreignKeys = await openedDatabase.getFirstAsync<{
        foreign_keys: number;
      }>('PRAGMA foreign_keys');

      if (!foreignKeys || Number(foreignKeys.foreign_keys) !== 1) {
        throw new Error(
          'SQLite no pudo habilitar la integridad de claves foráneas.'
        );
      }

      const integrity = await openedDatabase.getFirstAsync<{
        integrity_check: string;
      }>('PRAGMA integrity_check');

      if (
        !integrity ||
        String(integrity.integrity_check).toLowerCase() !== 'ok'
      ) {
        throw new Error(
          `La verificación de integridad SQLite falló: ${
            integrity?.integrity_check ?? 'sin resultado'
          }`
        );
      }

      this.database = openedDatabase;
    } catch (error) {
      if (openedDatabase) {
        try {
          await openedDatabase.closeAsync();
        } catch (closeError) {
          console.warn(
            '[Database] No se pudo cerrar la conexión fallida.',
            closeError
          );
        }
      }

      this.database = null;
      console.error('[Database Initialization Failed]', error);
      throw error;
    }
  }

  static getDb(): SQLite.SQLiteDatabase {
    if (!this.database) {
      throw new Error(
        'DatabaseService no ha sido inicializado. ' +
          'Ejecuta DatabaseService.initialize() previamente.'
      );
    }

    return this.database;
  }

  /**
   * Alias de compatibilidad.
   */
  static getDB(): SQLite.SQLiteDatabase {
    return this.getDb();
  }

  static async close(): Promise<void> {
    if (this.initializationPromise) {
      await this.initializationPromise;
    }

    const currentDatabase = this.database;
    this.database = null;

    if (currentDatabase) {
      await currentDatabase.closeAsync();
    }
  }

  static async getSchemaVersion(): Promise<number> {
    const database = this.getDb();

    const result = await database.getFirstAsync<SQLiteUserVersion>(
      'PRAGMA user_version'
    );

    return Number(result?.user_version ?? 0);
  }

  /**
   * Método de instancia para consumidores anteriores.
   */
  async initDB(): Promise<void> {
    await DatabaseService.initialize();
  }

  /**
   * Método de instancia para consumidores anteriores.
   */
  getDb(): SQLite.SQLiteDatabase {
    return DatabaseService.getDb();
  }

  /** Alias de instancia requerido por App.tsx */
  getDB(): SQLite.SQLiteDatabase {
    return DatabaseService.getDb();
  }

  async close(): Promise<void> {
    await DatabaseService.close();
  }

  // ── KEY-VALUE STORE ──────────────────────────────────────

  async setValue(key: string, value: string): Promise<void> {
    const normalizedKey = key.trim();

    if (!normalizedKey) {
      throw new Error('La clave del almacén no puede estar vacía.');
    }

    const database = DatabaseService.getDb();

    await database.runAsync(
      `INSERT INTO key_value_store (key, value)
       VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      normalizedKey,
      value
    );
  }

  async getValue(key: string): Promise<string | null> {
    const normalizedKey = key.trim();

    if (!normalizedKey) {
      return null;
    }

    const database = DatabaseService.getDb();

    const row = await database.getFirstAsync<KeyValueRow>(
      'SELECT value FROM key_value_store WHERE key = ?',
      normalizedKey
    );

    return row?.value ?? null;
  }

  async removeValue(key: string): Promise<void> {
    const normalizedKey = key.trim();

    if (!normalizedKey) {
      return;
    }

    const database = DatabaseService.getDb();

    await database.runAsync(
      'DELETE FROM key_value_store WHERE key = ?',
      normalizedKey
    );
  }
}

// ── SESSION REPOSITORY ──────────────────────────────────────

export class SessionRepository implements ISessionRepository {
  private getDatabase(): SQLite.SQLiteDatabase {
    return DatabaseService.getDb();
  }

  async getAll(): Promise<Session[]> {
    const database = this.getDatabase();

    const rows = await database.getAllAsync<DB_Session>(
      `SELECT *
       FROM sessions
       ORDER BY date DESC, start_time DESC`
    );

    return Promise.all(
      rows.map((row) => this.hydrateSession(database, row))
    );
  }

  async getById(id: string): Promise<Session | null> {
    const normalizedId = id.trim();

    if (!normalizedId) {
      return null;
    }

    const database = this.getDatabase();

    const row = await database.getFirstAsync<DB_Session>(
      'SELECT * FROM sessions WHERE id = ?',
      normalizedId
    );

    if (!row) {
      return null;
    }

    return this.hydrateSession(database, row);
  }

  async getByPeriod(
    startDate: string,
    endDate: string
  ): Promise<Session[]> {
    this.assertValidPeriod(startDate, endDate);

    const database = this.getDatabase();

    const rows = await database.getAllAsync<DB_Session>(
      `SELECT *
       FROM sessions
       WHERE date BETWEEN ? AND ?
         AND state = 'CERRADA'
       ORDER BY date DESC, start_time DESC`,
      startDate,
      endDate
    );

    return Promise.all(
      rows.map((row) => this.hydrateSession(database, row))
    );
  }

  async getActive(): Promise<Session | null> {
    const database = this.getDatabase();

    const row = await database.getFirstAsync<DB_Session>(
      `SELECT *
       FROM sessions
       WHERE end_time IS NULL
         AND state NOT IN ('CERRADA', 'NO_INICIADA')
       ORDER BY date DESC, start_time DESC
       LIMIT 1`
    );

    if (!row) {
      return null;
    }

    return this.hydrateSession(database, row);
  }

  async create(session: Session): Promise<Session> {
    this.validateSession(session);

    const database = this.getDatabase();
    const now = new Date().toISOString();

    await database.withTransactionAsync(async () => {
      await database.runAsync(
        `INSERT INTO sessions (
          id,
          date,
          destination,
          alias,
          start_time,
          end_time,
          total_hours,
          lunch_deducted_minutes,
          overtime_hours,
          snapshot_rate,
          total_earnings,
          integrity_type,
          notes,
          state,
          paid_minutes,
          pause_minutes,
          transfer_minutes,
          destination_count,
          _lat,
          _lng,
          _radius,
          _device_status,
          created_at,
          updated_at
        ) VALUES (
          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )`,
        session.id,
        session.date,
        session.destination,
        this.nullableString(session.alias),
        session.startTime,
        this.nullableEndTime(session.endTime),
        session.totalHours ?? 0,
        session.lunchDeductedMinutes ?? 0,
        session.overtimeHours ?? 0,
        session.snapshotRate ?? 20,
        session.totalEarnings ?? 0,
        session.integrityType ?? 'VALID',
        this.nullableString(session.notes),
        session.state ?? 'NO_INICIADA',
        session.paidMinutes ?? session.paid_minutes ?? 0,
        session.pauseMinutes ?? session.pause_minutes ?? 0,
        session.transferMinutes ?? session.transfer_minutes ?? 0,
        session.destinationCount ??
          session.destination_count ??
          Math.max(1, session.visits?.length ?? 0),
        session._lat ?? null,
        session._lng ?? null,
        session._radius ?? null,
        this.nullableString(session._deviceStatus),
        now,
        now
      );

      await this.replaceTimelineEvents(
        database,
        session.id,
        session.timelineEvents ?? []
      );

      await this.replaceVisits(
        database,
        session.id,
        session.visits ?? []
      );

      await this.replaceTransfers(
        database,
        session.id,
        session.transfers ?? []
      );

      await this.replaceBreaks(
        database,
        session.id,
        session.breaks ?? []
      );
    });

    const created = await this.getById(session.id);

    if (!created) {
      throw new Error(
        `No se pudo recuperar la sesión creada: ${session.id}`
      );
    }

    return created;
  }

  async update(
    id: string,
    patch: Partial<Session>
  ): Promise<Session> {
    const normalizedId = id.trim();

    if (!normalizedId) {
      throw new Error(
        'El identificador de la sesión no puede estar vacío.'
      );
    }

    const database = this.getDatabase();
    const existing = await database.getFirstAsync<DB_Session>(
      'SELECT * FROM sessions WHERE id = ?',
      normalizedId
    );

    if (!existing) {
      throw new Error(`Sesión no encontrada: ${normalizedId}`);
    }

    const fields: string[] = [];
    const values: SQLiteValue[] = [];

    const addField = (
      column: string,
      value: SQLiteValue
    ): void => {
      fields.push(`${column} = ?`);
      values.push(value);
    };

    if (patch.date !== undefined) {
      addField('date', patch.date);
    }

    if (patch.destination !== undefined) {
      addField('destination', patch.destination);
    }

    if (patch.alias !== undefined) {
      addField('alias', this.nullableString(patch.alias));
    }

    if (patch.startTime !== undefined) {
      addField('start_time', patch.startTime);
    }

    if (patch.endTime !== undefined) {
      addField(
        'end_time',
        this.nullableEndTime(patch.endTime)
      );
    }

    if (patch.totalHours !== undefined) {
      addField('total_hours', patch.totalHours);
    }

    if (patch.lunchDeductedMinutes !== undefined) {
      addField(
        'lunch_deducted_minutes',
        patch.lunchDeductedMinutes
      );
    }

    if (patch.overtimeHours !== undefined) {
      addField('overtime_hours', patch.overtimeHours);
    }

    if (patch.snapshotRate !== undefined) {
      addField('snapshot_rate', patch.snapshotRate);
    }

    if (patch.totalEarnings !== undefined) {
      addField('total_earnings', patch.totalEarnings);
    }

    if (patch.integrityType !== undefined) {
      addField('integrity_type', patch.integrityType);
    }

    if (patch.notes !== undefined) {
      addField('notes', this.nullableString(patch.notes));
    }

    if (patch.state !== undefined) {
      addField('state', patch.state);
    }

    const paidMinutes =
      patch.paidMinutes ?? patch.paid_minutes;

    if (paidMinutes !== undefined) {
      addField('paid_minutes', paidMinutes);
    }

    const pauseMinutes =
      patch.pauseMinutes ?? patch.pause_minutes;

    if (pauseMinutes !== undefined) {
      addField('pause_minutes', pauseMinutes);
    }

    const transferMinutes =
      patch.transferMinutes ?? patch.transfer_minutes;

    if (transferMinutes !== undefined) {
      addField('transfer_minutes', transferMinutes);
    }

    const destinationCount =
      patch.destinationCount ?? patch.destination_count;

    if (destinationCount !== undefined) {
      addField(
        'destination_count',
        Math.max(1, destinationCount)
      );
    } else if (patch.visits !== undefined) {
      addField(
        'destination_count',
        Math.max(1, patch.visits.length)
      );
    }

    if (patch._lat !== undefined) {
      addField('_lat', patch._lat);
    }

    if (patch._lng !== undefined) {
      addField('_lng', patch._lng);
    }

    if (patch._radius !== undefined) {
      addField('_radius', patch._radius);
    }

    if (patch._deviceStatus !== undefined) {
      addField(
        '_device_status',
        this.nullableString(patch._deviceStatus)
      );
    }

    await database.withTransactionAsync(async () => {
      if (fields.length > 0) {
        fields.push('updated_at = ?');
        values.push(new Date().toISOString());
        values.push(normalizedId);

        await database.runAsync(
          `UPDATE sessions
           SET ${fields.join(', ')}
           WHERE id = ?`,
          ...values
        );
      }

      if (patch.timelineEvents !== undefined) {
        await this.replaceTimelineEvents(
          database,
          normalizedId,
          patch.timelineEvents
        );
      }

      if (patch.visits !== undefined) {
        await this.replaceVisits(
          database,
          normalizedId,
          patch.visits
        );
      }

      if (patch.transfers !== undefined) {
        await this.replaceTransfers(
          database,
          normalizedId,
          patch.transfers
        );
      }

      if (patch.breaks !== undefined) {
        await this.replaceBreaks(
          database,
          normalizedId,
          patch.breaks
        );
      }
    });

    const updated = await this.getById(normalizedId);

    if (!updated) {
      throw new Error(
        `No se pudo recuperar la sesión actualizada: ${normalizedId}`
      );
    }

    return updated;
  }

  async delete(id: string): Promise<void> {
    const normalizedId = id.trim();

    if (!normalizedId) {
      return;
    }

    const database = this.getDatabase();

    await database.withTransactionAsync(async () => {
      await database.runAsync(
        'DELETE FROM wal_log WHERE session_id = ?',
        normalizedId
      );

      await database.runAsync(
        'DELETE FROM sessions WHERE id = ?',
        normalizedId
      );
    });
  }

  async getWeeklySummary(
    startDate: string,
    endDate: string
  ): Promise<WeeklySummary> {
    this.assertValidPeriod(startDate, endDate);

    const database = this.getDatabase();

    const [rows, settings] = await Promise.all([
      database.getAllAsync<WeeklySessionRow>(
        `SELECT
          total_hours,
          total_earnings,
          overtime_hours,
          snapshot_rate,
          integrity_type
         FROM sessions
         WHERE date BETWEEN ? AND ?
           AND state = 'CERRADA'`,
        startDate,
        endDate
      ),

      database.getFirstAsync<SettingsRateRow>(
        `SELECT hourly_rate, overtime_multiplier
         FROM settings
         WHERE id = ?`,
        SETTINGS_ID
      ),
    ]);

    const baseRate = this.finiteNumber(
      settings?.hourly_rate,
      20
    );

    const overtimeMultiplier = this.finiteNumber(
      settings?.overtime_multiplier,
      1.5
    );

    let totalHours = 0;
    let storedTotalEarnings = 0;
    let manualAdjustments = 0;
    let overtimeHours = 0;
    let baseEarnings = 0;
    let overtimeEarnings = 0;

    for (const row of rows) {
      const sessionHours = Math.max(
        0,
        this.finiteNumber(row.total_hours)
      );

      const sessionOvertime = Math.max(
        0,
        Math.min(
          sessionHours,
          this.finiteNumber(row.overtime_hours)
        )
      );

      const sessionBaseHours = Math.max(
        0,
        sessionHours - sessionOvertime
      );

      const sessionRate = Math.max(
        0,
        this.finiteNumber(row.snapshot_rate, baseRate)
      );

      totalHours += sessionHours;
      overtimeHours += sessionOvertime;

      baseEarnings += sessionBaseHours * sessionRate;

      overtimeEarnings +=
        sessionOvertime *
        sessionRate *
        overtimeMultiplier;

      storedTotalEarnings += Math.max(
        0,
        this.finiteNumber(row.total_earnings)
      );

      if (row.integrity_type === 'MANUAL') {
        manualAdjustments += 1;
      }
    }

    const calculatedTotalEarnings =
      baseEarnings + overtimeEarnings;

    const totalEarnings =
      storedTotalEarnings > 0
        ? storedTotalEarnings
        : calculatedTotalEarnings;

    return {
      periodLabel: `${startDate} - ${endDate}`,
      totalHours: this.roundCurrency(totalHours),
      totalEarnings: this.roundCurrency(totalEarnings),
      sessionCount: rows.length,
      manualAdjustments,
      overtimeHours: this.roundCurrency(overtimeHours),
      baseEarnings: this.roundCurrency(baseEarnings),
      overtimeEarnings: this.roundCurrency(
        overtimeEarnings
      ),
      baseRate: this.roundCurrency(baseRate),
      overtimeMultiplier,
    };
  }

  async getSnapshotRateForSession(
    sessionId: string
  ): Promise<number> {
    const database = this.getDatabase();

    const row = await database.getFirstAsync<SnapshotRateRow>(
      `SELECT snapshot_rate
       FROM sessions
       WHERE id = ?`,
      sessionId
    );

    return this.finiteNumber(row?.snapshot_rate, 20);
  }

  async checkOverlap(
    excludeId: string,
    date: string,
    newStart: string,
    newEnd: string
  ): Promise<boolean> {
    const newStartMinutes = this.timeToMinutes(newStart);
    const newEndMinutes = this.timeToMinutes(newEnd);

    if (newEndMinutes <= newStartMinutes) {
      throw new Error(
        'La hora final debe ser posterior a la hora inicial.'
      );
    }

    const database = this.getDatabase();

    const rows = await database.getAllAsync<OverlapRow>(
      `SELECT start_time, end_time
       FROM sessions
       WHERE date = ?
         AND id != ?
         AND state = 'CERRADA'
         AND end_time IS NOT NULL`,
      date,
      excludeId
    );

    return rows.some((row) => {
      if (!row.end_time) {
        return false;
      }

      const existingStart = this.timeToMinutes(row.start_time);
      const existingEnd = this.timeToMinutes(row.end_time);

      return (
        newStartMinutes < existingEnd &&
        newEndMinutes > existingStart
      );
    });
  }

  async closeOrphanSessions(): Promise<void> {
    const database = this.getDatabase();
    const now = new Date();
    const timestamp = now.toISOString();
    const today = timestamp.slice(0, 10);

    const orphanSessions =
      await database.getAllAsync<OrphanSessionRow>(
        `SELECT id, date, start_time
         FROM sessions
         WHERE state NOT IN ('CERRADA', 'NO_INICIADA')
           AND date < ?`,
        today
      );

    for (const session of orphanSessions) {
      // Se utiliza el final del día porque el tiempo real de salida
      // no puede reconstruirse de forma fiable.
      const automaticEndTime = `${session.date}T23:59:59.999`;

      await database.withTransactionAsync(async () => {
        await database.runAsync(
          `UPDATE sessions
           SET
             state = 'CERRADA',
             integrity_type = 'AUTO',
             end_time = ?,
             updated_at = ?
           WHERE id = ?`,
          automaticEndTime,
          timestamp,
          session.id
        );

        const currentSequence =
          await database.getFirstAsync<CountRow>(
            `SELECT COUNT(*) AS count
             FROM timeline_events
             WHERE session_id = ?`,
            session.id
          );

        await database.runAsync(
          `INSERT INTO timeline_events (
            id,
            session_id,
            timestamp,
            type,
            title,
            description,
            status,
            sequence,
            metadata
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          Crypto.randomUUID(),
          session.id,
          timestamp,
          'CERRADA',
          'Cierre automático',
          'Cierre automático por cambio de fecha',
          'closed',
          Number(currentSequence?.count ?? 0) + 1,
          JSON.stringify({
            source: 'DatabaseService.closeOrphanSessions',
            originalStartTime: session.start_time,
          })
        );
      });
    }
  }

  async purgeZeroHourSessions(): Promise<void> {
    const database = this.getDatabase();

    await database.runAsync(
      `DELETE FROM sessions
       WHERE total_hours <= 0
         AND state = 'CERRADA'`
    );
  }

  // ── RELATIONAL REPOSITORIES ──────────────────────────────

  async getVisits(
    sessionId: string
  ): Promise<DestinationVisit[]> {
    const database = this.getDatabase();

    const rows =
      await database.getAllAsync<DB_DestinationVisit>(
        `SELECT *
         FROM destination_visits
         WHERE session_id = ?
         ORDER BY enter_time ASC`,
        sessionId
      );

    return rows.map((row) => ({
      id: row.id,
      sessionId: row.session_id,
      destination: row.destination,
      alias: row.alias ?? undefined,
      enterTime: row.enter_time,
      exitTime: row.exit_time ?? undefined,
      lat: this.optionalNumber(row.lat),
      lng: this.optionalNumber(row.lng),
    }));
  }

  async getTransfers(
    sessionId: string
  ): Promise<Transfer[]> {
    const database = this.getDatabase();

    const rows = await database.getAllAsync<DB_Transfer>(
      `SELECT *
       FROM transfers
       WHERE session_id = ?
       ORDER BY start_time ASC`,
      sessionId
    );

    return rows.map((row) => ({
      id: row.id,
      sessionId: row.session_id,
      originDestination: row.origin_destination,
      targetDestination: row.target_destination,
      destination: row.target_destination,
      startTime: row.start_time,
      endTime: row.end_time ?? undefined,
      isPaid: row.is_paid === 1,
    }));
  }

  async getBreaks(
    sessionId: string
  ): Promise<Break[]> {
    const database = this.getDatabase();

    const rows = await database.getAllAsync<DB_Break>(
      `SELECT *
       FROM breaks
       WHERE session_id = ?
       ORDER BY start_time ASC`,
      sessionId
    );

    return rows.map((row) => ({
      id: row.id,
      sessionId: row.session_id,
      startTime: row.start_time,
      endTime: row.end_time ?? undefined,
      durationMinutes: this.finiteNumber(
        row.duration_minutes
      ),
      isPaid: row.is_paid === 1,
    }));
  }

  // ── APPLICATION WAL ──────────────────────────────────────

  async appendWALEntry(
    sessionId: string,
    eventType: string,
    payload: unknown
  ): Promise<string> {
    const normalizedSessionId = sessionId.trim();
    const normalizedEventType = eventType.trim();

    if (!normalizedSessionId || !normalizedEventType) {
      throw new Error(
        'sessionId y eventType son obligatorios para registrar el WAL.'
      );
    }

    const id = Crypto.randomUUID();
    const serializedPayload = JSON.stringify(payload);

    if (serializedPayload === undefined) {
      throw new Error(
        'El payload del WAL no puede serializarse.'
      );
    }

    const database = this.getDatabase();

    await database.runAsync(
      `INSERT INTO wal_log (
        id,
        session_id,
        event_type,
        payload,
        created_at,
        synced
      ) VALUES (?, ?, ?, ?, ?, 0)`,
      id,
      normalizedSessionId,
      normalizedEventType,
      serializedPayload,
      new Date().toISOString()
    );

    return id;
  }

  async getPendingWALEntries(
    sessionId?: string
  ): Promise<WALRow[]> {
    const database = this.getDatabase();

    if (sessionId?.trim()) {
      return database.getAllAsync<WALRow>(
        `SELECT *
         FROM wal_log
         WHERE synced = 0
           AND session_id = ?
         ORDER BY created_at ASC`,
        sessionId.trim()
      );
    }

    return database.getAllAsync<WALRow>(
      `SELECT *
       FROM wal_log
       WHERE synced = 0
       ORDER BY created_at ASC`
    );
  }

  async markWALEntrySynced(id: string): Promise<void> {
    const normalizedId = id.trim();

    if (!normalizedId) {
      return;
    }

    const database = this.getDatabase();

    await database.runAsync(
      'UPDATE wal_log SET synced = 1 WHERE id = ?',
      normalizedId
    );
  }

  async purgeSyncedWALEntries(): Promise<void> {
    const database = this.getDatabase();

    await database.runAsync(
      'DELETE FROM wal_log WHERE synced = 1'
    );
  }

  // ── HYDRATION ────────────────────────────────────────────

  private async hydrateSession(
    database: SQLite.SQLiteDatabase,
    row: DB_Session
  ): Promise<Session> {
    const [events, visits, transfers, breaks] =
      await Promise.all([
        this.getTimelineEvents(database, row.id),
        this.getVisits(row.id),
        this.getTransfers(row.id),
        this.getBreaks(row.id),
      ]);

    return this.mapRowToSession(
      row,
      events,
      visits,
      transfers,
      breaks
    );
  }

  private async getTimelineEvents(
    database: SQLite.SQLiteDatabase,
    sessionId: string
  ): Promise<TimelineEvent[]> {
    const rows =
      await database.getAllAsync<DB_TimelineEvent>(
        `SELECT *
         FROM timeline_events
         WHERE session_id = ?
         ORDER BY sequence ASC, timestamp ASC`,
        sessionId
      );

    return rows.map((row) => ({
      id: row.id,
      timestamp: row.timestamp,
      type: this.optionalSessionState(row.type),
      title: row.title || undefined,
      description: row.description ?? '',
      status: this.normalizePillStatus(row.status),
      metadata: row.metadata ?? undefined,
    }));
  }

  private mapRowToSession(
    row: DB_Session,
    events: TimelineEvent[],
    visits: DestinationVisit[],
    transfers: Transfer[],
    breaks: Break[]
  ): Session {
    return {
      id: row.id,
      date: row.date,
      destination: row.destination,
      alias: row.alias ?? undefined,
      startTime: row.start_time,
      endTime: row.end_time ?? '',
      totalHours: this.finiteNumber(row.total_hours),
      lunchDeductedMinutes: this.finiteNumber(
        row.lunch_deducted_minutes
      ),
      overtimeHours: this.finiteNumber(
        row.overtime_hours
      ),
      snapshotRate: this.finiteNumber(
        row.snapshot_rate,
        20
      ),
      totalEarnings: this.finiteNumber(
        row.total_earnings
      ),
      integrityType: row.integrity_type,
      notes: row.notes ?? undefined,
      state: row.state,
      timelineEvents: events,
      visits,
      transfers,
      breaks,
      paidMinutes: this.finiteNumber(row.paid_minutes),
      pauseMinutes: this.finiteNumber(row.pause_minutes),
      transferMinutes: this.finiteNumber(
        row.transfer_minutes
      ),
      destinationCount: Math.max(
        1,
        this.finiteNumber(row.destination_count, 1)
      ),
      _lat: this.optionalNumber(row._lat),
      _lng: this.optionalNumber(row._lng),
      _radius: this.optionalNumber(row._radius),
      _deviceStatus: row._device_status ?? undefined,
    };
  }

  // ── RELATION REPLACEMENT ─────────────────────────────────

  private async replaceTimelineEvents(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    events: TimelineEvent[]
  ): Promise<void> {
    await database.runAsync(
      'DELETE FROM timeline_events WHERE session_id = ?',
      sessionId
    );

    const usedIds = new Set<string>();

    for (let index = 0; index < events.length; index += 1) {
      const event = events[index];
      let eventId = event.id?.trim() || Crypto.randomUUID();

      if (usedIds.has(eventId)) {
        eventId = Crypto.randomUUID();
      }

      usedIds.add(eventId);

      const timestamp =
        event.timestamp?.trim() ||
        event.time?.trim() ||
        new Date().toISOString();

      const title =
        event.title?.trim() ||
        event.description.trim();

      await database.runAsync(
        `INSERT INTO timeline_events (
          id,
          session_id,
          timestamp,
          type,
          title,
          description,
          status,
          sequence,
          metadata
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        eventId,
        sessionId,
        timestamp,
        event.type ?? null,
        title,
        event.description,
        event.status,
        index + 1,
        this.nullableString(event.metadata)
      );
    }
  }

  private async replaceVisits(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    visits: DestinationVisit[]
  ): Promise<void> {
    await database.runAsync(
      'DELETE FROM destination_visits WHERE session_id = ?',
      sessionId
    );

    const usedIds = new Set<string>();

    for (const visit of visits) {
      let visitId = visit.id?.trim() || Crypto.randomUUID();

      if (usedIds.has(visitId)) {
        visitId = Crypto.randomUUID();
      }

      usedIds.add(visitId);

      const destination =
        visit.destination?.trim() ||
        visit.name?.trim() ||
        '';

      const enterTime =
        visit.enterTime?.trim() ||
        visit.arrival_time?.trim() ||
        '';

      const exitTime =
        visit.exitTime ??
        visit.departure_time ??
        null;

      if (!destination || !enterTime) {
        throw new Error(
          `La visita ${visitId} requiere destination y enterTime.`
        );
      }

      await database.runAsync(
        `INSERT INTO destination_visits (
          id,
          session_id,
          destination,
          alias,
          enter_time,
          exit_time,
          lat,
          lng
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        visitId,
        sessionId,
        destination,
        this.nullableString(visit.alias),
        enterTime,
        this.nullableEndTime(exitTime ?? undefined),
        visit.lat ?? null,
        visit.lng ?? null
      );
    }
  }

  private async replaceTransfers(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    transfers: Transfer[]
  ): Promise<void> {
    await database.runAsync(
      'DELETE FROM transfers WHERE session_id = ?',
      sessionId
    );

    const usedIds = new Set<string>();

    for (const transfer of transfers) {
      let transferId =
        transfer.id?.trim() || Crypto.randomUUID();

      if (usedIds.has(transferId)) {
        transferId = Crypto.randomUUID();
      }

      usedIds.add(transferId);

      const origin =
        transfer.originDestination?.trim() ||
        transfer.origin_destination?.trim() ||
        '';

      const target =
        transfer.targetDestination?.trim() ||
        transfer.target_destination?.trim() ||
        transfer.destination?.trim() ||
        '';

      const startTime =
        transfer.startTime?.trim() ||
        transfer.start_time?.trim() ||
        '';

      const endTime =
        transfer.endTime ??
        transfer.end_time ??
        null;

      const isPaid =
        transfer.isPaid ??
        (transfer.is_paid !== undefined
          ? transfer.is_paid === 1
          : true);

      if (!origin || !target || !startTime) {
        throw new Error(
          `El traslado ${transferId} requiere origen, destino y hora inicial.`
        );
      }

      await database.runAsync(
        `INSERT INTO transfers (
          id,
          session_id,
          origin_destination,
          target_destination,
          start_time,
          end_time,
          is_paid
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        transferId,
        sessionId,
        origin,
        target,
        startTime,
        this.nullableEndTime(endTime ?? undefined),
        isPaid ? 1 : 0
      );
    }
  }

  private async replaceBreaks(
    database: SQLite.SQLiteDatabase,
    sessionId: string,
    breaks: Break[]
  ): Promise<void> {
    await database.runAsync(
      'DELETE FROM breaks WHERE session_id = ?',
      sessionId
    );

    const usedIds = new Set<string>();

    for (const workBreak of breaks) {
      let breakId =
        workBreak.id?.trim() || Crypto.randomUUID();

      if (usedIds.has(breakId)) {
        breakId = Crypto.randomUUID();
      }

      usedIds.add(breakId);

      const startTime =
        workBreak.startTime?.trim() ||
        workBreak.start_time?.trim() ||
        '';

      const endTime =
        workBreak.endTime ??
        workBreak.end_time ??
        null;

      const durationMinutes =
        workBreak.durationMinutes ??
        workBreak.duration_minutes ??
        0;

      const isPaid =
        workBreak.isPaid ??
        (workBreak.is_paid !== undefined
          ? workBreak.is_paid === 1
          : false);

      if (!startTime) {
        throw new Error(
          `La pausa ${breakId} requiere una hora inicial.`
        );
      }

      if (
        !Number.isFinite(durationMinutes) ||
        durationMinutes < 0
      ) {
        throw new Error(
          `La pausa ${breakId} contiene una duración inválida.`
        );
      }

      await database.runAsync(
        `INSERT INTO breaks (
          id,
          session_id,
          start_time,
          end_time,
          duration_minutes,
          is_paid
        ) VALUES (?, ?, ?, ?, ?, ?)`,
        breakId,
        sessionId,
        startTime,
        this.nullableEndTime(endTime ?? undefined),
        durationMinutes,
        isPaid ? 1 : 0
      );
    }
  }

  // ── VALIDATION AND NORMALIZATION ─────────────────────────

  private validateSession(session: Session): void {
    if (!session.id?.trim()) {
      throw new Error(
        'El identificador de la sesión no puede estar vacío.'
      );
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(session.date)) {
      throw new Error(
        'La fecha de la sesión debe utilizar el formato YYYY-MM-DD.'
      );
    }

    if (!session.destination?.trim()) {
      throw new Error(
        'El destino de la sesión no puede estar vacío.'
      );
    }

    if (!session.startTime?.trim()) {
      throw new Error(
        'La hora inicial de la sesión no puede estar vacía.'
      );
    }

    if (
      !Number.isFinite(session.snapshotRate) ||
      session.snapshotRate < 0
    ) {
      throw new Error(
        'La tarifa snapshot debe ser un número no negativo.'
      );
    }

    if (
      session._lat !== undefined &&
      (session._lat < -90 || session._lat > 90)
    ) {
      throw new Error(
        'La latitud debe encontrarse entre -90 y 90.'
      );
    }

    if (
      session._lng !== undefined &&
      (session._lng < -180 || session._lng > 180)
    ) {
      throw new Error(
        'La longitud debe encontrarse entre -180 y 180.'
      );
    }

    if (
      session._radius !== undefined &&
      (!Number.isFinite(session._radius) ||
        session._radius <= 0)
    ) {
      throw new Error(
        'El radio de geocerca debe ser mayor que cero.'
      );
    }
  }

  private assertValidPeriod(
    startDate: string,
    endDate: string
  ): void {
    const datePattern = /^\d{4}-\d{2}-\d{2}$/;

    if (
      !datePattern.test(startDate) ||
      !datePattern.test(endDate)
    ) {
      throw new Error(
        'El periodo debe utilizar fechas con formato YYYY-MM-DD.'
      );
    }

    if (startDate > endDate) {
      throw new Error(
        'La fecha inicial no puede ser posterior a la fecha final.'
      );
    }
  }

  private timeToMinutes(value: string): number {
    const normalized = value.includes('T')
      ? value.split('T')[1]?.slice(0, 5) ?? ''
      : value.slice(0, 5);

    const match = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(
      normalized
    );

    if (!match) {
      throw new Error(`Hora inválida: ${value}`);
    }

    return Number(match[1]) * 60 + Number(match[2]);
  }

  private nullableString(
    value: string | undefined | null
  ): string | null {
    if (value === undefined || value === null) {
      return null;
    }

    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }

  private nullableEndTime(
    value: string | undefined | null
  ): string | null {
    return this.nullableString(value);
  }

  private finiteNumber(
    value: number | null | undefined,
    fallback = 0
  ): number {
    const numericValue = Number(value);

    return Number.isFinite(numericValue)
      ? numericValue
      : fallback;
  }

  private optionalNumber(
    value: number | null | undefined
  ): number | undefined {
    if (value === null || value === undefined) {
      return undefined;
    }

    const numericValue = Number(value);

    return Number.isFinite(numericValue)
      ? numericValue
      : undefined;
  }

  private roundCurrency(value: number): number {
    return Math.round((value + Number.EPSILON) * 100) / 100;
  }

  private optionalSessionState(
    value: SessionState | string | null
  ): SessionState | undefined {
    switch (value) {
      case 'NO_INICIADA':
      case 'ESPERANDO':
      case 'TRASLADO':
      case 'ACTIVA':
      case 'PAUSADA':
      case 'SALIDA':
      case 'CERRADA':
        return value;

      default:
        return undefined;
    }
  }

  private normalizePillStatus(
    value: string
  ): PillStatus {
    switch (value) {
      case 'idle':
      case 'pending':
      case 'active':
      case 'warning':
      case 'error':
      case 'closed':
        return value;

      default:
        return 'idle';
    }
  }
}

// ── SINGLETON EXPORTS ───────────────────────────────────────

export const databaseService = new DatabaseService();

export const sessionRepository = new SessionRepository();

export { DB_SCHEMA };

